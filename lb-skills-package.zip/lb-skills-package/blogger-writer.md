---
name: blogger-writer
description: |
  按照真实博主的风格写文章（第一人称、面向新加坡读者）。当用户说"用XX风格写"、"模仿XX博主"、
  "按照[博主名]写一篇关于XX的文章"、或要求生成符合特定博主语气的内容时，使用此 skill。
  已收录 16 位博主，覆盖：Tesla/EV（Chris Zheng）、产品增长（Lenny Rachitsky）、美联储/宏观
  （Nick Timiraos、Lance Roberts、Meet Kevin）、技术分析（Rayner Teo）、长期投资
  （Joseph Carlson、The Plain Bagel、InvestNotBet）、期权与市场结构（Michael Kramer）、
  中文财经科普（小lin说、美投讲美股）、新加坡本地投资（SG Stocks Investing、Investmoolah、
  Fifth Person、TradingKey）。可指定博主，也可让 AI 根据主题自动匹配。
  触发词：blogger-writer、用XX的风格写、按照XX博主写、模仿XX、以XX的语气
allowed-tools:
  - Read
  - Write
  - Glob
  - WebSearch
  - Bash
---

# Blogger Writer — 博主风格文章生成

> 学习真实博主的写作风格、内容领域和语言习惯，输出对应风格的文章。所有输出面向**新加坡读者**，默认以**第一人称"我"**写作。

---

## 已收录博主（16 位）

完整索引和自动匹配规则见 `{baseDir}/bloggers/INDEX.md`。下表为快速查询：

| 博主ID | 博主 | 平台 | 擅长领域 | 原文语言 |
|--------|------|------|---------|---------|
| `lenny` | Lenny Rachitsky | Substack | 产品管理、增长、PM 职业、AI 工具 | EN |
| `chris-zheng` | Chris Zheng | X | Tesla 中国、EV、自动驾驶、供应链 | EN/中 |
| `nick-timiraos` | Nick Timiraos | X + WSJ | 美联储、货币政策、利率、通胀 | EN |
| `joseph-carlson` | Joseph Carlson | YouTube + X | 美股长期投资、成长股、个人组合 | EN |
| `rayner-teo` | Rayner Teo | X + Blog | 技术分析、交易策略、风险管理 | EN |
| `xiao-lin-shuo` | 小lin说 | YouTube | 财经科普、宏观经济、商业故事 | 中 |
| `meitou-meiguu` | 美投讲美股 | YouTube | 美股个股、财报解读、估值 | 中 |
| `the-plain-bagel` | The Plain Bagel | YouTube | 金融教育、行为金融、投资原理 | EN |
| `meet-kevin` | Meet Kevin | YouTube | 美股热点快评、美联储即时解读 | EN |
| `sg-stocks-investing` | SG Stocks Investing | Blog | SG REITs、SGX、CPF、Singapore property | EN |
| `trading-key` | TradingKey | Web + App | 全球股票、IPO、加密、商品、宏观 | EN |
| `lance-roberts` | Lance Roberts | TalkMarkets | 宏观周期、Fed policy、组合风险 | EN |
| `michael-kramer` | Michael Kramer | TalkMarkets | 期权结构、VIX/gamma、S&P 500 日评 | EN |
| `investmoolah` | Investmoolah | Blog | SG REITs、股息投资、个人组合日记 | EN |
| `investnotbet` | InvestNotBet | Blog | 长期投资、避免交易陷阱、ETF | EN |
| `fifth-person` | The Fifth Person | Blog + YouTube | 价值成长、SG/Asia REITs、股息组合 | EN |

---

## 触发方式

用户可以这样说（自然语言，不需要严格的命令格式）：

- "用 Lenny 的风格写一篇关于 AI agents 产品策略的文章"
- "模仿 Chris Zheng 写小米 SU7 最新销量数据"
- "按照 sg-stocks-investing 的语气写一篇 Mapletree REITs 的分析"
- "帮我写一篇关于美联储降息的短评"（未指定博主，自动匹配 → `nick-timiraos`）

---

## 执行流程

### Step 1: 确定博主风格

**指定了博主**：读取 `{baseDir}/bloggers/{id}.md` 获取风格档案。

**未指定**：读取 `{baseDir}/bloggers/INDEX.md` 末尾的"自主选择规则"，根据主题匹配。匹配后**先告知用户**："I'll write this in [博主名]'s style because the topic best fits their domain." 让用户有机会换人。

---

### Step 2: 主题调研（如涉及时事/具体公司/数据）

用 WebSearch 补充：最新动态、关键数字、官方引语、事件时间线。把调研到的数据点先列出来，写作时引用，事实核查时核对。

---

### Step 3: 写作

按所选博主的风格档案执行。除了忠实还原档案里的**语气、结构、句式、要避免的写法**之外，**以下七条全局规则适用于所有博主**：

#### 规则 1: 第一人称视角

**默认用 "我"**，不要用"我们"指代博主本人。

**为什么**：这些都是**个人博主**，不是机构或团队。把博主本人说成"我们"会让文章读起来像券商研报或公司公告，瞬间丢失个人语气。
- 中文："我觉得 / 我注意到 / 我手上这只 REIT"
- 英文："I think / I noticed / the REIT I hold"

**"我们"的允许场景**：当 "我们 / we / our / us" 是**作者 + 读者的共指**（博主在跟读者群体说话），是允许的，而且通常是好的：它拉近距离，营造对话感。

判断方法：把这句话里的"我们"换成"我和你"，意思通不通？
- ✅ 通："这对我们普通人意味着什么？" → "这对我和你这样的普通人意味着什么？"（成立）
- ✅ 通："Our local rates feel it." → "My rate and your rate both feel it."（成立）
- ❌ 不通："我们认为 MIT 值得持有" → "我和你都认为 MIT 值得持有"（不成立，这是博主自己的观点冒充群体）

**特别适合用共指"我们"的博主**：
- `xiao-lin-shuo`（招牌句"这对我们普通人意味着什么"）
- `the-plain-bagel`、`lenny`（教学型，"let's walk through..."、"我们一起来看"）
- `sg-stocks-investing`、`investmoolah`（散户社群感，"as Singapore investors, we..."）

**例外（博主代表团队/品牌）**：极少数情况下博主代表 newsletter 团队或公司，按档案指示。

**Step 3.5 扫描要点**：搜全文 "我们 / we / our / us"，对每一处问"这是博主本人，还是博主 + 读者？"。前者改成"我 / I"，后者保留。

#### 规则 2: 面向新加坡读者本地化

**用词**：直接使用本地缩写，不要展开翻译
- SGD / S$（不写"新元独立成段"）、HDB、CPF、SGX、STI、MAS、GIC、Temasek 等
- 美股代码保持原样（NVDA、TSLA），不译成中文
- REIT 不译"房地产投资信托"
- "Mapletree"、"CapitaLand"、"DBS"、"OCBC" 等本地公司名保持英文

**数字单位**：
- 英文输出：用 `USD 5 billion` / `SGD 200 million`，不用 `$5B` 或 `5 亿美元`
- 中文输出：用"5 亿美元"、"2 亿新元"，不混用 `5B USD`
- 给参照：`USD 5 billion (about 6% of revenue)` 比裸数字好

**语气**：专业但不端着。介于 Bloomberg 和朋友聊天之间
- 不用研报腔："综上所述"、"建议关注"、"值得期待"、"具备投资价值"
- 不用过度口语："bro"、"yo"、"绝绝子"、"yyds"、"破天荒"
- 可以引用本地语境（Shenton Way、Raffles Place、组屋、CPF SA），但不强求每篇都用

**平台规范（Longbridge 社区专用）**：
- ❌ 严禁提及任何竞品平台：moomoo、Tiger Brokers、富途、老虎证券、Futu、uSMART 等一律不得出现
- ✅ 如需提及交易平台，只用 Longbridge，或不提具体平台名

#### 规则 3: 降低阅读成本

- **短句优先**：一句话能说清的不写两句。一段不超过 4 行
- **首段抛观点/钩子**：不要"背景→分析→结论"的论文结构。博主写法是先给观点、给数据、给问题，再展开
- **首次出现的术语带提示**：第一次写 `VIX` 时带 `(the volatility index)`，之后直接用
- **数字给参照系**：`USD 5 billion` → `USD 5 billion, roughly half of Tesla's annual capex`
- **避免嵌套从句**：`The company, which had previously announced..., is now considering...` → 拆成两个短句

#### 规则 4: 去 AI 化标点与句式（重要）

LLM 输出最容易暴露身份的就是这些特征，逐项避开：

**禁止使用 em dash（—）**：一律不得出现，无论任何博主风格，无一例外
- ❌ `Tesla's Q3 was strong — deliveries hit 462k, a record.`
- ✅ `Tesla's Q3 was strong. Deliveries hit 462k, a record.`
- ✅ `Tesla's Q3 was strong: deliveries hit 462k, a record.`
- 替代：补充说明用冒号 `:` 或括号 `()`，转折用句号断句

**避开 LLM 套路词**：`Moreover`、`Furthermore`、`In conclusion`、`It's worth noting that`、`That said,`（开头时）、`Ultimately`

**避开 LLM 套路句式**：
- ❌ "not just X, but Y" / "not only... but also..."
- ❌ 每段都"主语 + 强动词"开头那种过度对称的排比
- ❌ "This isn't just about A; it's about B"

#### 规则 5: Emoji（按博主风格判断，克制使用）

**适合用 emoji** 的博主：
- `chris-zheng`（X 短贴，原本就常用 🚗 ⚡ 🇨🇳 🇺🇸）
- `meet-kevin`（高能量快评，🚨 📈 📉 适配）
- `sg-stocks-investing`、`investmoolah`（散户博客，可用 💰 🏠 🇸🇬）
- `trading-key`（情绪标记 🔥 📊）

**不适合用 emoji** 的博主：
- `lenny`（长文 Newsletter，最多偶尔一个 👇）
- `nick-timiraos`（WSJ 严肃记者，0 emoji）
- `lance-roberts`、`michael-kramer`（机构研报口吻，0 emoji）
- `the-plain-bagel`、`investnotbet`（理性科普，emoji 削弱可信度）

**通用约束**：
- 一篇文章 0-3 个 emoji，不是装饰
- 放在情绪/视觉锚点上（开头钩子、数字旁强化方向）
- 中文输出比英文输出更克制

#### 规则 6: 中文母语博主 → 英文输出时的翻译规范

适用于：`xiao-lin-shuo`、`meitou-meiguu`、以及 `chris-zheng` 当用户要求中文档案产英文文章的场景。

**保留博主语气**：小lin说的故事化口吻翻译后仍应是 narrative storytelling，不要变成教科书；美投讲美股的数据驱动感保留，不要软化成科普。

**用词对照（容易翻译失真的高频词）**：

| 中文原词 | ❌ 别用 | ✅ 用 |
|---------|--------|-------|
| 美元 / 人民币 | US Dollar / Chinese Yuan | USD / RMB |
| 互联网公司 | internet companies | tech companies |
| (造车)新势力 | new forces | EV startups / Chinese EV makers |
| 韭菜 | leeks / chives | retail investors |
| 割韭菜 | cutting the leeks | fleecing retail investors |
| 做多 / 做空 | go more / go empty | long / short |
| 复盘 | replay / re-board | recap / review |
| 画大饼 | drawing big pancakes | overpromising |
| 抄底 | copy the bottom | buy the dip |
| 解套 | untie | exit a losing position |
| 行情 | the line | the market / price action |
| A 股 | A-share market | China A-shares |
| 港股 | HK stocks | Hong Kong stocks / HKEX-listed |

**数字单位**：
- "1 亿美元" → `USD 100 million`，不写 `100M USD` 也不写 `0.1B`
- "万亿" → `trillion`，不写 `10000 亿`

**要避免的**：直译中式比喻、四字成语硬译、把"老铁/家人们"翻成 "iron buddies / family members"。找不到对应表达就重写一句，保留意思不保留形式。

#### 规则 7: 输出长度与形式参考

按博主类型，不死板。**形式优先由内容复杂度决定，不由博主身份决定**：

- **长文 Newsletter**（`lenny`、`fifth-person` 深度篇、`investnotbet`）：800–2000 字，带标题和分节
- **博客中篇**（`sg-stocks-investing`、`investmoolah`、`lance-roberts`、`the-plain-bagel`）：500–1200 字，带标题
- **短文 / 短贴**（`chris-zheng`、`meet-kevin`、`michael-kramer`、`nick-timiraos`）：100–400 字，1–3 段，**不需要编号**
- **Numbered Thread**（任何博主均可用，但前提是内容有 4+ 个独立步骤/角度）：3–8 条编号推文

**关于 nick-timiraos 和 rayner-teo**：这两位最常见的形式是 2–3 段短文，而不是 thread。只有当内容需要逐步拆解时（如政策路径分析 5 步、交易策略 6 步）才用 thread 形式。

---

### Step 3.5: 事实核查与最终扫描（不可跳过）

文章写完后，逐一核查：

- **sg-market-news 立场核查（写作前必做，优先级最高）**：在本次对话中查找 sg-market-news 输出的「📌 今日立场摘要」，加载为当日立场基准表，用于后续每篇帖子的马甲号指定。具体规则见下方「观点一致性规则（同日同号同股）→ 来源一」。

- **当日去重（最高优先级）**：回顾本次对话中今天已输出的所有帖子，逐篇比对：
  - 同一标的是否已用相同博主风格写过？→ 换博主或换角度
  - 核心论点/观点是否与已有帖子雷同？→ 必须换切入点（如：已写过"MU估值分析"，新帖改写"MU供应链视角"或"持仓操作建议"）
  - 同一格式（如 blog/thread/短贴）是否已连续出现？→ 换格式
  - **同一天任何时候输出的帖子不得雷同，包括跨多次对话输入产生的内容**
  - 判断标准：两篇帖子如果核心信息、主要论点、博主视角高度相似，读者看了第二篇没有新收获 → 必须重写

- **数字交叉验证**：每个数字与 Step 2 调研的原始数据比对
- **数量级与单位**：重点防"亿/万"混用、USD/SGD/HKD/RMB 混用、百分比计算错误
- **本地化用词扫一遍**：是否还有"新元"被写成"Singapore Dollar"全称这种冗余翻译
- **第一人称扫一遍**：搜全文 "我们 / we / our / us"，每一处问"这是博主本人冒充群体（→ 改成"我 / I"），还是博主 + 读者的共指（→ 保留）？"
- **AI 指纹扫一遍**：搜索 `—`、`Moreover`、`Furthermore`、`In conclusion`、`not just ... but ...`，命中就改

发现问题立即修正，再进入 Step 4。

---

### Step 4: 输出

直接在对话中输出。每篇帖子头部标注博主和主题：

```
---
Blogger style: [博主名]
Topic: [主题]
---

[正文]

**发帖账号:** [单一马甲号]
```

---

#### 内容形式选择（重要）

**不要默认用 numbered thread（1/ 2/ 3/）。** 这只是多种形式之一，只有在内容真的需要分步展开时才用。根据内容性质和博主平台，从以下形式中选最合适的：

| 形式 | 适用场景 | 示例博主 |
|------|---------|---------|
| **单条推文 / 单段贴** | 一个观点、一条数据、一句感叹，150字以内说清楚 | chris-zheng、meet-kevin、michael-kramer 日评 |
| **2–3 段短文** | 有背景+观点+结论，但不复杂，不需要编号，直接分段落 | nick-timiraos、rayner-teo、meet-kevin 长一点的贴 |
| **Numbered Thread（1/ 2/ 3/...）** | 内容有明确的多步骤、多角度，需要读者顺序跟读；一般 4 条以上才值得做 thread | nick-timiraos 重大政策解读、rayner-teo 交易步骤拆解 |
| **Blog 文章（带标题 + 分节）** | 深度分析，500字以上，有标题和 H2 小节 | lenny、sg-stocks-investing、lance-roberts、the-plain-bagel、fifth-person、investmoolah |
| **Quote + 短评** | 引用某人原话 / 数据，下方加一两句个人点评 | nick-timiraos（引用 Fed 官员）、michael-kramer（引用市场数据）|
| **列表贴** | 3–5 个并列要点，适合"X件事要知道"类内容 | trading-key、meet-kevin、the-plain-bagel |

**判断逻辑**：
- 内容只有 1 个核心点 → 单条推文或 2 段短文，**不要硬拆成 thread**
- 内容有 2–3 个层次但逻辑连贯 → 分段落写，不编号
- 内容有 4+ 个独立步骤/角度，读者需要顺序跟 → 才用 numbered thread
- 长文分析 → 带标题的博客格式

同一次对话输出多篇时，**形式要有变化**，不能全部是 thread，也不能全部是单段贴。

---

#### 格式附加规则

- **标题**：长文（lenny、lance-roberts、the-plain-bagel、investnotbet、trading-key、fifth-person 等）需要标题；短评和推文不需要标题
- **段落间距**：长文段落之间多空一行；**无标题的短评**（chris-zheng、meet-kevin、michael-kramer、nick-timiraos 等）段落之间空两行。由于 Markdown 渲染会合并连续空行，必须在两段之间插入一个仅含 `&nbsp;` 的占位行，格式为：`段落A → 空行 → &nbsp; → 空行 → 段落B`，确保复制粘贴时空行得以保留
- **禁止品牌化开场白**：不使用博主专属的自我介绍式开场，如 "Welcome back everyone, today on the Joseph Carlson Show" 等。只模仿风格，不冒充账号身份

---

### Step 5：今日立场摘要（本次所有帖子输出完毕后立即追加，无需等待用户指令）

回顾本次生成的所有帖子，对每一个"马甲号 × 标的"组合判断其实际立场，输出可直接粘贴到回复评论书签 ⚙️ 面板的摘要块。

**判断立场（看帖子内容的核心方向）：**

| 内容表达 | stance |
|---------|--------|
| 看好、上涨、买入、超预期 | `bullish` |
| 担忧、下行风险、减仓、利空 | `bearish` |
| 中立观望、无明确方向 | `neutral` |
| 专注数据/逻辑分析、不表态方向 | `analysis` |
| 承认利好但强调风险、有条件乐观 | `cautious` |

**输出格式（可直接复制粘贴）：**

```
📌 今日立场摘要（复制粘贴到书签 ⚙️）
马甲号:ticker:stance
马甲号:ticker:stance
```

**ticker 写法**（须与书签识别词一致）：

| 标的 | ticker |
|------|--------|
| NVDA / Nvidia / Intel / AMD | `nvda` |
| Micron / SanDisk / WDC / Seagate | `sandisk` |
| Tesla / TSLA / BYD / 小鹏 / EV | `tesla` |
| Apple / AAPL | `apple` |
| Alibaba / BABA | `alibaba` |
| 黄金 / Gold / GLD / SLV | `gold` |
| Microsoft / Meta / Amazon / Google / Mag7 | `microsoft` |
| ASML | `asml` |
| DBS / OCBC / UOB / SG蓝筹 / SGX | `dbs` |
| 加密 / COIN / MSTR / Bitcoin | `coin` |
| 美联储 / Fed / FOMC / CPI / 宏观 | `nasdaq` |
| Xiaomi / 小米 | `xiaomi` |

没有对应行的标的：用股票代码或公司名小写。每个"马甲号:标的"只写一行，立场取帖子的主要方向。

---

## 事件优先级与帖子排序

当用户提供多个事件时，**先分析重要性，再按优先级从高到低输出帖子**。

### 优先级框架

**Tier 1 — 财报 🥇**
任何公司实际业绩数据出炉，永远最优先

**Tier 2 — 重大事件 🥈**
- 重大产品发布会（Google I/O、Apple WWDC 等）
- 七姐妹发生重大公司事件（裁员、并购、重大公告等）
- IPO 重大进展
- 单日异动 ≥5% 的标的

Tier 2 内部子排序（受众广度优先）：
1. 重大产品发布会（行业影响面最广）
2. 七姐妹重大事件
3. IPO 重大进展
4. 单日异动 ≥5%

**Tier 3 — 热点标的分析 🥉**
- 美股七姐妹日常讨论（无重大事件时）
- 新加坡 SGX 蓝筹 / REITs
- 存储板块（MU / SNDK / HBM 链）

**Tier 4 — 宏观背景**
30Y UST、Fed、油价、黄金、地缘政治（垫底）

**同一 Tier 内**：按受众覆盖广度排序（持仓人数多、讨论热度高的标的优先）。

> 注：Tier 2 的触发条件是**事件本身的性质**，不是公司身份。同一标的当天有重大事件按 Tier 2 排，无重大事件则按 Tier 3 排。

---

## 马甲号匹配规则

每篇帖子输出后，直接指定一个最合适的发帖账号。不输出排序列表，直接给出结论。

**指定逻辑（按优先级依次判断）：**
1. **人设匹配**：帖子核心主题对应的专精账号优先（见下方匹配表）
2. **使用次数**：该账号在本次 blogger-writer 输出中已用满 3 次（sg-market-news 使用次数不计）→ 自动换同人设备选，或通用账号
3. **观点一致性**：该账号今天已对同一股票发过帖子 → 核查立场是否冲突；冲突则换账号，不改立场
4. **无明确标的**：从通用账号池随机选一个当天未超额的

**以下两个账号已剔除，不推荐使用：** Competitive_Ride、KayaToast

### 每日轮换规则（同一次对话内全局执行）

**同一个账号在同一天的 blogger-writer 输出中最多出现 3 次。** sg-market-news Phase 3 的使用次数**不计入**此限制。超过 3 次时，自动切换为同人设的备选账号，或换用通用账号。

执行方式：在同一次对话中，仅对 blogger-writer 本身生成的帖子计数，达到 3 次后不再推荐该账号，直到用户开启新一天的对话。

目标：让账号分布尽量分散，不让某一个账号包揽所有帖子，降低账号过度活跃的风险。

**切换示例**：
- `SuperTesla` 已用 3 次 → 切换到 `TeslaInvestor_先锋` 或 `Revolution～`
- `Bluegate1104` 已用 3 次 → 切换到 `Kellyk310`、`TaylorSwift007` 等通用账号
- `Alpha` 已用 3 次（且无同主题备选）→ 切换到通用账号，注明"Alpha 今日额度已满"

### 观点一致性规则（同日同号同股）

**同一天内，同一马甲号对同一只股票的观点不得相矛盾。立场来源包括两处，必须同时核查：**

#### 来源一：sg-market-news 今日立场摘要

每次开始生成博主风格帖子前，**第一步**：在本次对话中搜索 sg-market-news 输出的「📌 今日立场摘要」块（格式为 `马甲号:ticker:stance` 的多行列表）。

- 若找到，将其加载为当日**立场基准表**
- 后续每次指定马甲号前，查表确认该账号对该标的是否已有立场记录
- 若已有记录且方向一致 → 可用
- 若已有记录且方向冲突 → 换账号，不改帖子立场
- 若无记录 → 正常指定，同时将新立场纳入心理账本

> 注：sg-market-news 今日立场摘要仅用于核查**立场方向**是否冲突，不影响账号在 blogger-writer 中的使用次数计算。

**示例**：
- 今日立场摘要显示 `Alpha:nvda:bullish` → blogger-writer 本次不得用 Alpha 发任何 NVDA 看空帖（但若 Alpha 在 sg-market-news 中已用过 2 次，在 blogger-writer 中仍可继续使用，直到 blogger-writer 内部计数达 3 次）
- 今日立场摘要显示 `Crab clps:microsoft:bullish` → 本次可继续用 Crab clps 发 Meta 看多帖（方向一致），但不得发看空帖

#### 来源二：本次对话内 blogger-writer 已输出的帖子

- 如果 `Fair_Lemon5303` 今天发过一篇看多 MU 的帖子，同一天不能再用该账号发看空 MU 的帖子
- 如果 `Alpha` 今天已表达"NVDA 估值偏高"，同一天不能再用该账号发"NVDA 是最佳买入机会"
- 判断标准：核心方向性立场（看多/看空/中性）必须一致，措辞侧重可以不同（技术面/基本面/短期/长期）

**执行方式**：生成马甲号前，同时检查来源一（sg-market-news 立场摘要）和来源二（本次对话已输出），两处均无冲突才可指定该账号。

### 马甲号索引表

| 马甲号 | 股票 / 人设 |
|--------|-----------|
| Alpha | 英伟达、英特尔、AMD |
| Fair_Lemon5303 | 存储概念股：闪迪、美光科技、西部数据、Seagate |
| levon911 | 存储概念股：闪迪、美光科技、西部数据、Seagate |
| watchdog01 | 币股：BMNR、CRCL、COIN、MSTR |
| HeyItsDaniel | 币股：BMNR、CRCL、COIN、MSTR |
| Revolution～ | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| Aurelius | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| PumpLord_69 | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| beta-one | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| Moose | 阿里巴巴 |
| SuperTesla | 特斯拉 |
| TeslaInvestor_先锋 | 特斯拉 |
| clown crowd | 黄金白银概念股：GLD、SLV、AGQ、GSD、5TP等 |
| andwagon effect | 黄金白银概念股：GLD、SLV、AGQ、GSD、5TP等 |
| joker2018 | 黄金白银概念股：GLD、SLV、AGQ、GSD、5TP等 |
| Steve_Z | 苹果 |
| rocket shadow | 美股7姐妹 |
| Fantastic | 美股7姐妹 |
| greeeedy options | 美股7姐妹 |
| Crab clps | 美股7姐妹 |
| All In Call | 美股7姐妹 |
| Big_Angel | 美股7姐妹 |
| Showdown | 美股7姐妹 |
| Crazy rich | 新加坡股：D05 |
| NewUser_oDPBc9 | 以新手角度提问，带动用户互动 |
| TaylorSwift007 | 通用 |
| Kellyk310 | 通用 |
| jackson beat it | ASML |
| imJanice | 通用 |
| Bluegate1104 | 纳斯达克、美联储 |
| markypots | 小米 |
| korbs23 | 通用 |
| 定D来 | 通用 |
| 绿箭牌2.5元 | 通用 |
| 大王进山 | 通用 |
| 新手买哪个? | 通用 |
| Ethan1 | 通用 |
| ButterKaya | 通用 |
| applepie | 通用 |
| JeremyT | The Fifth Person 风格 |
| Jessy_0723 | 通用 |
| Christina | 通用 |
| XX | TradingKey 风格 |
| Yqh | 通用 |
| Eunice | 通用 |
| Louis_t | 通用 |
| millionaire | 通用 |
| orange | 通用 |
| TXY | 通用 |
| KopiO | 通用 |
| TehC | 通用 |
| ZLH_1230 | 通用 |

### 匹配逻辑

**核心原则：按帖子核心主题匹配，不按出现过的标的词匹配。**

帖子里提到某标的数据，不等于帖子主题是该标的。判断方法：把帖子主题用一句话概括，概括结果里的核心词才是匹配依据。

> 反例：一篇讲地缘政治 + 油价的帖子顺带提到"黄金 ETF 跌 1.6%"→ 主题是宏观/地缘，不是黄金 → 不推 andwagon effect，应推 Bluegate1104 或通用账号。

> 正例：一篇专门分析黄金 ETF 走势、讨论 GLD/SLV 操作策略的帖子 → 主题是黄金/白银 → 推 andwagon effect > clown crowd。

**有明确股票标签的账号优先匹配对应标的：**

| 帖子主题 | 首选账号 | 备选（首选满额或有冲突时）|
|---------|---------|--------------------------|
| 英伟达 / 英特尔 / AMD / AI芯片 | Alpha | 通用账号 |
| 存储板块（MU、SNDK、WDC、Seagate） | Fair_Lemon5303 | levon911 |
| 特斯拉 | SuperTesla | TeslaInvestor_先锋 → Revolution～ → Aurelius |
| 新能源汽车（BYD、小鹏等） | Revolution～ | Aurelius → PumpLord_69 → beta-one |
| 苹果 | Steve_Z | Crab clps |
| 美股七姐妹（泛七姐妹讨论） | Crab clps | All In Call → Big_Angel → Showdown → rocket shadow → Fantastic → greeeedy options |
| ASML | jackson beat it | 通用账号 |
| 小米 | markypots | 通用账号 |
| 阿里巴巴 | Moose | 通用账号 |
| 加密 / 币股 | watchdog01 | HeyItsDaniel |
| 黄金 / 白银 / 大宗商品 | andwagon effect | clown crowd → joker2018 |
| 宏观 / 美联储 / 纳斯达克指数 | Bluegate1104 | 通用账号 |
| 新加坡股 / DBS | Crazy rich | 通用账号 |
| TradingKey 风格帖子 | XX | 通用账号 |
| The Fifth Person 风格帖子 | JeremyT | 通用账号 |
| 带动新手互动 / 提问型帖子 | NewUser_oDPBc9 | 通用账号 |
| 无明确标的（通用） | 从以下池随机选一个当天未超额的：TaylorSwift007、Kellyk310、Ethan1、ButterKaya、Christina、Yqh、Eunice、Louis_t、millionaire、orange、TXY、KopiO、TehC、ZLH_1230 | — |

---

## 新增博主

如果用户说"新增博主 XXX，主页是 YYY"：

1. 用 WebSearch / WebFetch 研究该博主 5-10 篇代表作，识别语气、结构、高频句式、要避免的写法
2. 在 `{baseDir}/bloggers/` 创建新档案，参考现有文件（推荐参考 `lenny-rachitsky.md` 或 `chris-zheng.md` 的结构）
3. 更新 `{baseDir}/bloggers/INDEX.md` 的索引表和自动匹配规则
4. 同步更新本 SKILL.md 顶部"已收录博主"表（保持两处一致）
5. 告知用户：博主已收录，ID 为 `{id}`

---

## 参考文件

- `{baseDir}/bloggers/INDEX.md` — 完整博主索引 + 自动匹配规则
- `{baseDir}/bloggers/{id}.md` — 各博主的风格档案（共 16 个）
