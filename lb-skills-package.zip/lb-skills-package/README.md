# LB Community Skills — 安装说明

本包含 2 个 Claude Code Skill：

| Skill | 触发词 | 功能 |
|-------|--------|------|
| `sg-market-news` | `/sg-market-news` | 新加坡市场每日简报 + 社区讨论帖（Phase 1-3） |
| `blogger-writer` | `/blogger-writer` | 16 位博主风格文章生成 |

---

## 安装步骤

### 1. 确认已安装 Claude Code

```bash
claude --version
```

### 2. 将文件复制到 Claude 命令目录

```bash
# 创建目录（如不存在）
mkdir -p ~/.claude/commands/bloggers

# 复制文件（替换 /path/to/this/folder 为解压路径）
cp /path/to/this/folder/sg-market-news.md ~/.claude/commands/
cp /path/to/this/folder/blogger-writer.md ~/.claude/commands/
cp /path/to/this/folder/bloggers/*.md ~/.claude/commands/bloggers/
```

### 3. 重启 Claude Code，验证安装

打开 Claude Code，输入 `/sg-market-news` 或 `/blogger-writer`，若有提示即安装成功。

---

## 快速使用

**每日新加坡市场简报：**
```
/sg-market-news 给我今天（2026年X月X日 周X）的新加坡市场新闻
```

**博主风格写帖：**
```
/blogger-writer 用 meet-kevin 的风格写一篇关于 NVDA 财报的帖子
/blogger-writer 给几篇 Dell 财报相关的帖子
```

---

## 文件结构

```
~/.claude/commands/
├── sg-market-news.md       ← SG 市场简报 Skill
├── blogger-writer.md       ← 博主风格写作 Skill
└── bloggers/               ← 16 位博主风格档案
    ├── INDEX.md
    ├── chris-zheng.md
    ├── meet-kevin.md
    ├── nick-timiraos.md
    └── ... (共 16 个)
```

---

## 已收录博主（16 位）

| 博主 | 领域 |
|------|------|
| Chris Zheng | Tesla / EV / 自动驾驶 |
| Nick Timiraos | 美联储 / 货币政策 |
| Lenny Rachitsky | 产品策略 / AI |
| Joseph Carlson | 美股长期投资 |
| Rayner Teo | 技术分析 / 交易策略 |
| Meet Kevin | 美股热点快评 |
| Lance Roberts | 宏观周期 / 组合风险 |
| Michael Kramer | 期权结构 / VIX |
| The Plain Bagel | 金融教育 / 行为金融 |
| 小lin说 | 财经科普（中文） |
| 美投讲美股 | 美股财报（中文） |
| TradingKey | 全球股票 / IPO / 宏观 |
| SG Stocks Investing | 新加坡股 / REITs |
| Investmoolah | SG 股息投资 / 组合日记 |
| InvestNotBet | 长期投资 / ETF |
| The Fifth Person | 价值成长 / SG REITs |

---

*如有问题联系安装人员。*
