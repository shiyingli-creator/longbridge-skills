---
id: fifth-person
name: The Fifth Person
platform: Blog (fifthperson.com) + YouTube + Podcast
url: https://fifthperson.com/
topics: [value-growth investing, Singapore REITs, Asian equities, US equities, financial literacy, dividend investing, AGM coverage]
language: English
---

# The Fifth Person 写作风格档案

## 背景

Award-winning Singapore investment platform founded in 2014 by Rusmin Ang, Victor Chng, and Adam Wong. Two-time winner of the SGX Orb Award for Best Independent Investment Website (2018 & 2020). With 50,000+ newsletter subscribers and 41K+ YouTube subscribers, The Fifth Person is one of the most trusted retail investment voices in Singapore. Their style is rooted in value-growth investing principles — combining fundamental research with a practical, accessible writing approach aimed at helping everyday investors achieve financial independence. Articles are editorial-quality, well-researched, and written with the conviction of investor-practitioners who have real money in the game.

## 内容领域

- Value-growth stock analysis (Singapore, Malaysia, Asia, US equities)
- Singapore and Asian REIT analysis and selection
- Annual General Meeting (AGM) coverage and notes
- Financial literacy for beginners and intermediate investors
- Dividend investing and passive income building
- US equities (Apple, Nvidia, sector themes)
- Market review and thematic trend analysis (AI, data centres, cashless society)
- CPF strategies and Singapore personal finance

## 语气特征

- **Warm and empowering** — "we want to help you make better investment decisions", not "we know best"
- **Evidence-based confidence** — conclusions are backed by financial data and fundamental analysis, not speculation
- **Accessible without dumbing down** — explains valuation metrics and REIT structures clearly, without condescension
- **Long-term oriented** — consistently steers readers toward patient, quality-focused investing vs. trading
- **Conversational and engaging** — reads like a conversation with a knowledgeable peer, not a textbook
- **Singapore-rooted, globally aware** — always anchors to Singapore context (SGX, CPF, SGD) but covers Asian and US markets
- **Community-minded** — engages with reader questions, acknowledges losses openly, builds trust over time
- **Slightly bold on themes** — "If 2024 was the year of hype and 2025 the year of building, 2026 will be the year of accountability"

## 文章结构

**Stock/REIT analysis format:**
```
1. Opening hook — a bold thesis or intriguing question about the company/market
2. Business overview — what the company does, its market position, key metrics
3. Investment thesis — why this is (or isn't) worth considering
4. Financial analysis — revenue, earnings growth, dividends, debt ratios
5. Key risks — what could go wrong
6. Valuation — is it cheap or expensive relative to peers and history?
7. Conclusion — clear buy/hold/watch/avoid stance with reasoning
```

**Thematic/educational format:**
```
1. Attention-grabbing title with a strong hook
2. Big picture context — why this theme matters now
3. Illustrative examples — real companies, real numbers
4. Historical parallels — what past cycles teach us
5. Investor takeaway — what to do (or avoid) given the theme
6. CTA — newsletter, membership, further reading
```

## 用词风格

- Warm, readable English — no financial jargon without explanation
- First-person plural for brand voice: "We believe...", "Our view is...", "We've been watching..."
- Empowering language: "Here's what you need to know", "This is how you can benefit"
- Singapore references: SGX, SGD, CPF, MAS, "listed in Singapore", Straits Times Index
- Valuation vocabulary explained in context: "price-to-earnings (P/E) ratio", "dividend yield", "net asset value (NAV)"
- Balanced call phrasing: "We remain cautiously optimistic", "This is a quality business, but valuation matters"
- Bold thematic statements for articles: "2026 will be the year of accountability"

## 标志性表达

| 句式 | 示例 |
|------|------|
| Bold thematic opener | "If 2024 was the year of hype and 2025 the year of building, then 2026 will be remembered for something far more brutal: the year of accountability." |
| Empowering framing | "Here's what you need to know to make a better investment decision." |
| Mission anchor | "We believe that investment knowledge and smart financial habits can help millions achieve financial independence." |
| Balanced stance | "This is a quality business at a reasonable price — but position sizing matters." |
| Singapore grounding | "For Singapore investors, the key consideration is..." |
| Community voice | "We've had nearly 10,000 members go through our courses and take action to achieve their financial goals." |
| Long-term reframe | "In the short term, markets are unpredictable. In the long term, quality always wins." |
| Dividend clarity | "Build a $12K/Year Dividend Portfolio — Even If You're Starting Small" |

## 适合用 The Fifth Person 风格写的主题

- Singapore and Asian REIT deep dives (fundamentals + valuation)
- Value-growth stock analysis (SGX, Bursa, HK, US markets)
- AGM notes and management Q&A summaries
- Financial literacy explainers (how REITs work, what P/E means, etc.)
- Thematic market outlook articles (AI investing, data centres, dividend portfolios)
- CPF and Singapore personal finance strategy
- "Is X a good investment?" accessible stock assessments

## 写作时要避免的

- Don't be sensational or short-term focused — the brand is built on long-term, patient investing
- Don't skip the fundamentals — always anchor opinions in financial data (revenue, earnings, dividends)
- Don't write without a clear investment stance — ambiguity is not the Fifth Person style
- Don't use overly complex jargon without defining it — accessibility is core
- Don't ignore risks — every bullish view must acknowledge what could go wrong
- Don't write as a lone individual — the brand voice is collegial ("we", "our", "the team")
