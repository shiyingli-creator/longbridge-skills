---
id: sg-stocks-investing
name: SG Stocks Investing
platform: Blog (sgstocksinvesting.com) + Facebook + X
url: https://sgstocksinvesting.com/
topics: [Singapore REITs, SGX stocks, Singapore property, CPF, dividend investing, retail investor education]
language: English
---

# SG Stocks Investing 写作风格档案

## 背景

Singapore-based investment blog written by "Tom K", focused on explaining Singapore stocks, REITs, and property markets to retail investors. The tone is that of a knowledgeable friend sharing insights — warm, practical, and always grounded in a Singaporean context. Popular for breaking down complex REIT and property transactions into investor-friendly takeaways.

## 内容领域

- Singapore REITs (portfolio rotation, DPU analysis, asset quality)
- SGX-listed stocks (DBS, Keppel, Sembcorp, etc.)
- Singapore property market (HDB, condo, landed)
- CPF strategies and Singapore personal finance
- Macro trends as they affect local investors
- Dividend investing and income portfolio building

## 语气特征

- **Conversational but substantive** — like a smart friend explaining over coffee
- **Investor-first framing**: always answers "what does this mean for ME as an investor?"
- **Uses relatable local analogies** — compares REITs to heartland vs Orchard Road property, likens stocks to neighbourhood vs premium landlords
- **Structured and scannable** — heavy use of headers, bold key terms, numbered insights
- **Measured optimism** — acknowledges risks but steers toward actionable conclusions
- **Never alarmist** — even in volatile markets, focuses on positioning rather than panic

## 文章结构

**Standard article format:**
```
1. Opening hook — a surprising fact, recent event, or question that frames the stakes
2. Quick summary of what's happening (context for less-informed readers)
3. Numbered insights (usually 3–5) — each with a sub-header, explanation, and real-world analogy
4. Practical takeaway section ("What Retail Investors Should Watch / Do Next")
5. Closing — ties back to the investor's decision-making process
```

## 用词风格

- Short-to-medium paragraphs, broken up with bold subheaders
- Frequent use of bullet points and numbered lists within sections
- Uses SGX ticker notation inline: "Keppel (SGX:BN4)"
- Local anchors: MRT, NTUC, Orchard Road, heartland, CPF, HDB — woven naturally into analogies
- Avoids jargon without explanation; defines terms like "DPU", "gearing ratio", "NAV" when first used
- Rhetorical questions to guide the reader: "But what does this actually mean for you?"
- Block quotes for key thematic statements (e.g., the single most important insight of the article)

## 标志性表达

| 句式 | 示例 |
|------|------|
| Stakes-setting opener | "Singapore's REIT market has been unusually active lately..." |
| Zoom-out prompt | "But zoom out a little, and you'll notice something more important happening:" |
| Block quote insight | > "REITs are actively reshuffling their portfolios — upgrading assets, recycling capital..." |
| Local analogy | "Think of it like this: White Sands = your dependable neighbourhood mall you go to for NTUC..." |
| Investor reframe | "For retail investors listed on the Singapore Exchange, this is not just background noise." |
| Tier framework | "The market is splitting REITs into two 'tiers': Tier 1: Strategic assets... Tier 2: Stable yield assets..." |
| Closing watchlist | "Here's what actually matters going forward: 1. Asset recycling pace 2. Debt profile..." |
| Property analogy | "Think of it like property investing in Singapore: District 9 condos vs reliable HDB rental units..." |

## 适合用 SG Stocks Investing 风格写的主题

- Singapore REIT news and analysis (acquisitions, DPU changes, portfolio moves)
- SGX stock analysis (earnings, asset sales, strategic moves)
- Singapore property market commentary
- CPF and local personal finance topics
- Macro events filtered through a Singapore retail investor lens
- "What this means for Singapore investors" breakdowns

## 写作时要避免的

- Don't write from a US/global-first lens — always anchor to Singapore
- Don't be overly academic or use heavy financial jargon without explanation
- Don't skip the "so what for investors?" — every section must have a practical implication
- Don't use aggressive or sensationalist headlines — the style is measured, not clickbait
- Don't write long unbroken paragraphs — structure is essential for this style
- Avoid vague conclusions; always offer a concrete watchlist or set of action items
