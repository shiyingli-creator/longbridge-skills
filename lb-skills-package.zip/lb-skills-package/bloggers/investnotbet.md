---
id: investnotbet
name: InvestNotBet
platform: Blog (investnotbet.com)
url: https://investnotbet.com/
topics: [long-term investing, stock analysis, avoiding trading traps, ETFs, crypto risk management, US equities, geopolitical risk investing]
language: English
---

# InvestNotBet 写作风格档案

## 背景

InvestNotBet is an independent investment blog written from the perspective of a long-term investor who has experienced both significant wins (SGD 1 million gains) and hard lessons learned. The blog's core mission is to help retail investors avoid the gambling and trading traps that destroy portfolios — and instead build wealth through disciplined, long-term investing. Articles are thoughtful, independently-minded, and written with a "calm and reasoned" authority that contrasts deliberately with the urgency and noise of financial social media.

## 内容领域

- Long-term stock and ETF investing (S&P 500, QQQ, individual equities)
- Stock analysis: US tech stocks (NVDA, Intel, PLTR, Anthropic-adjacent)
- Avoiding gambling/trading traps (0DTE options, day trading risks, meme stocks)
- Bitcoin and crypto with risk-management framing
- Geopolitical risk and portfolio positioning (US-Iran, tariffs, global shocks)
- Stock market education (investor psychology, valuation basics)
- Personal finance and saving habits

## 语气特征

- **Measured and calm** — deliberately anti-urgency; never sensational even on big market events
- **First-person authority from experience** — "From SGD 1 Million Gains to Lessons Learned" as a credential
- **Skeptical of hype** — pushes back on consensus "sure bets" (NVDA not guaranteed, PLTR volatility, etc.)
- **Educating from the investor's POV** — explains why a company's narrative matters but also why the price might not follow
- **Risk-first framing** — always asks "what could go wrong?" before "what's the upside?"
- **Independent analysis** — not beholden to any house view; calls things as the data suggests
- **Disclaimer-conscious** — consistently opens with "For information only. Not financial advice."
- **Long-form but focused** — articles run 800–2,000 words but stay tightly on the central thesis

## 文章结构

**Stock analysis format (most common):**
```
1. Disclaimer — "For information only. Not financial advice."
2. Headline — takes a specific position or asks a provocative question
3. Context — why this stock/topic is getting attention now
4. Bull case — what the market believes and why
5. Bear/risk case — what the market might be missing (often the core insight)
6. Specific risk factors — numbered or bulleted
7. Conclusion — balanced but directional; what the investor should consider
```

**Geopolitical/macro impact format:**
```
1. The shock event — what happened
2. The key question framing — "The real question is not whether X. It's whether Y."
3. Scenario analysis — how different outcomes play out for investors
4. Portfolio positioning — what asset classes or sectors benefit/suffer
5. Risk management note — how to size exposure given uncertainty
```

## 用词风格

- Clean, formal English — no slang, no casual filler words
- "For information only. Not financial advice." as a consistent opening disclaimer
- Measured hedging: "may", "could", "appears to be", "suggests" — not "will" or "guaranteed"
- Risk vocabulary: "downside risk", "tail risk", "valuation premium", "concentration risk"
- Contrarian framing: "NVIDIA is not a sure-shot best stock to buy" — challenges obvious consensus
- Specific data when cited: percentages, market cap figures, return statistics
- ETF-first for education: frequently uses "S&P 500 ETF", "QQQ" as benchmarks and alternatives
- Calm imperative in conclusions: "investors would be wise to consider...", "it may be prudent to..."

## 标志性表达

| 句式 | 示例 |
|------|------|
| Opening disclaimer | "For information only. Not financial advice." |
| Key question reframe | "The real question is not only whether conflict begins. The real question is how long the disruption lasts." |
| Hype pushback | "A great company is not always a low-risk stock." |
| Calm contrarian | "NVIDIA has been one of the biggest winners of the AI boom... But a great company is not always a low-risk stock." |
| Risk-first framing | "Before considering the upside, investors should understand the risks." |
| Experience credential | "(My real story) From SGD 1 Million Gains to Lessons Learned" |
| Specific event hook | "A single deleted tweet wiped $23 billion from Palantir's market cap in one day." |
| Conclusion tone | "Here is a calm, long-term breakdown of what is really happening." |

## 适合用 InvestNotBet 风格写的主题

- US tech stock analysis with bull/bear balance (NVDA, Intel, PLTR, AAPL, etc.)
- Debunking "obvious" investment narratives (is X really a sure buy?)
- Geopolitical risk and portfolio positioning
- Why ETFs and long-term investing beat trading/gambling
- Crypto with risk-management framing
- Investor psychology and avoiding common mistakes
- Macro events filtered through a rational, long-term investor lens

## 写作时要避免的

- Don't open without the disclaimer ("For information only. Not financial advice.")
- Don't be bullish without acknowledging the bear case — risk-first is the core differentiator
- Don't use sensational or urgent language — the brand identity is "calm and reasoned"
- Don't skip the investor psychology angle — the "why do people make this mistake" layer is important
- Don't avoid specific data points — claims need numbers behind them
- Don't write as a promoter — the style is explicitly independent and skeptical of hype
