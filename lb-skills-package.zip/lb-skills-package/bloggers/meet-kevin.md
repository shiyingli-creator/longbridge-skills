---
id: meet-kevin
name: Meet Kevin (Kevin Paffrath)
platform: YouTube
url: https://www.youtube.com/@MeetKevin
topics: [美股热点, 宏观经济新闻, 房地产, 个人投资, 财经时事]
language: 英文（可写中文版本）
---

# Meet Kevin 写作风格档案

## 背景

美国高产财经 YouTuber，Kevin Paffrath 主持，日更甚至多更。以快速响应财经新闻、高频输出市场观点著称。内容涵盖美股、宏观经济、房地产、加密货币等，风格极具个人色彩和煽动性。曾参选加州州长。粉丝数百万，以普通美国中产投资者为核心受众。

## 内容领域

- 美股市场日常动态与热点评论
- 美联储政策与宏观经济新闻
- 个股快评（财报反应、涨跌分析）
- 房地产投资
- 个人投资哲学与仓位分享
- 加密货币（周期性）

## 语气特征

- **高能量、紧迫感强**——语气永远像"现在有重要事情要告诉你"
- **强烈的个人观点**：从不含糊，直接说"I think the market is going to..."
- **煽动性但有逻辑**：会用夸张标题，但内容里有实际数据和论点
- **速度感**：快速切换话题，信息密度高，不拖沓
- **自信甚至有点傲**：对自己的判断很自信，会直接批评其他分析师
- **接地气**：频繁提到自己的真实持仓、买房经历，让普通人有代入感
- 标题党是风格的一部分，但内容要有干货支撑

## 文章/视频结构

**新闻快评型（最常见）：**
```
1. 开场：今天最重要的事（紧迫感）
2. 核心信息：直接说发生了什么
3. 为什么重要：对市场/投资者的影响
4. 个人判断：Kevin 的看法是什么
5. 操作建议：他自己怎么做/打算怎么做
6. 催促行动："Make sure you watch/subscribe..."
```

**宏观分析型：**
```
1. 大标题结论（先给观点）
2. 数据支撑（CPI、就业、财报数字）
3. 历史对比（"last time we saw this was..."）
4. 个人看多/看空理由
5. 风险因素
6. 个人持仓/操作
```

## 用词风格

- 感叹号、大写词常见（HUGE、THIS IS BIG）
- 紧迫词汇："right now"、"this is massive"、"you need to know this"
- 直接预测："I think we're going to see..."、"My bet is..."
- 批评词汇：会直接说"that's wrong"、"people are missing this"
- 口语化："guys"、"honestly"、"look"、"here's the thing"
- 数字驱动：具体到小数点，引用实时数据

## 标志性表达

| 句式 | 示例 |
|------|------|
| 紧迫开场 | "This is massive. You need to understand what just happened." |
| 直接预测 | "I think the Fed is going to cut in September. Here's why." |
| 个人持仓 | "I've been adding to my position in [X] because..." |
| 批评他人 | "A lot of people are getting this wrong." |
| 强调重要性 | "This is the most important chart you'll see today." |
| 催促互动 | "Hit that like button if this was helpful." |
| 历史对比 | "The last time we saw numbers like this was [year], and then..." |
| 结论先行 | "Bottom line: the market is [bullish/bearish] because..." |
| 承认过度扩张 | "I took on too much."（公开坦白失误，反而增强观众信任） |

## 补充：几个重要的更新和补充

1. **ETF $PP 已于2025年2月正式关闭**：他在2022年11月推出了 The Meet Kevin Pricing Power ETF（代号$PP），但因为押注美国国债的赌注在加息环境下被打爆，加上过度扩张，ETF于2025年2月关闭，他个人亏损约100万美元。这是他形象上的重要事件——他公开承认"I took on too much"。这个事件让他的内容多了一层"高能量但会翻车"的真实感，写他的风格时要考虑这个背景。

2. **他是"breaking news first"的执行者**：他的核心竞争力之一是成为"第一个报道"的创作者——不只是有观点，而是争速度。档案中提到"速度感"但没有明确这一点。

3. **内容演变轨迹**：从最初的房地产文档 → 疫情期间爆发的市场评论 → 宏观/美联储/个股全覆盖。他在COVID期间是很多美国普通投资者的"镇定剂式声音"，这个定位和档案描述的"高能量、紧迫感"并不矛盾——他对普通人也有情绪安抚作用。

4. **多更是算法策略**：日更甚至多更不只是内容驱动，而是刻意的 YouTube 算法优化——这是他区别于精品单更博主的核心商业逻辑。

5. **档案描述整体准确**，"标题党"部分正确，但要补充：他的标题虽然夸张，内容实际上包含有效数据和论点（不是空洞的标题党），这一点档案有提及但可以更强调。

## 适合用 Meet Kevin 风格写的主题

- 美股市场日内重大事件快评
- 美联储会议/CPI/非农数据即时解读
- 财报季个股涨跌快评
- 宏观经济转折点分析
- 市场恐慌或狂热时的观点文章

## 写作时要避免的

- 不要平淡（他的风格就是高能量，平淡就失去精髓）
- 不要没有个人明确判断（他从不骑墙）
- 不要只有观点没有数据（情绪背后要有数字支撑）
- 不要拖沓（他的节奏很快，废话极少）
- 不要模仿他的标题党而内容空洞（标题夸张但内容要有货）
