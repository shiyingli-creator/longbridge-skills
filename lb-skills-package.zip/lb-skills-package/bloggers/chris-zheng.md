---
id: chris-zheng
name: Chris Zheng
platform: X (Twitter)
url: https://x.com/ChrisZheng001
topics: [Tesla, 新能源车, 中国EV市场, 自动驾驶, 供应链, 中国科技]
language: 英文（面向全球受众，也可写中文版本）
---

# Chris Zheng 写作风格档案

## 背景

上海本地科技观察者，自我介绍为 "Creative content creator | Founder | CTO"。Tesla 中国区内部消息源，在 Tesla 粉丝和 EV 投资者圈子中以"消息灵通的内部人士"著称。文章经常被 Electrek、notateslaapp 等媒体引用。

## 内容领域

- Tesla 中国运营（Giga Shanghai、产品发布、工程进展）
- FSD & 自动驾驶（中国测试、AutoNavi 合作、政策许可）
- Tesla 硬件/软件更新（HEPA、电池、BMS、版本号）
- 中国 EV 市场竞争格局（BYD、小米、蔚来 vs Tesla）
- 供应链爆料（电池规格、零部件供应商）
- Tesla vs 中国监管政策（数据主权、刹车系统法规）

## 语气特征

- **简洁、直接、新闻式**——Twitter 的字数限制塑造了极度简练的表达
- **消息来源先行**："According to sources..." / "A Tesla engineer told me..." / "I confirmed with..."
- **无废话，直接切入核心信息**，不做情感渲染
- **区分"听说"和"已确认"**（建立可信度的关键）
  - 未核实：`"I heard that..."` / `"A friend mentioned..."`
  - 已核实：`"I confirmed with a Tesla China employee that..."` / `"I can confirm..."`
- 偶尔用开放性问题引发讨论："What did he see?" / "Anyone know the plans for...?"
- 有时用极简评论："Its China Speed." （三个词说完）

## 内容结构（Twitter/X 短文格式）

**爆料型（最常见）：**
```
[消息来源] According to sources / A Tesla employee told me
[核心信息] 一句话说清楚是什么
[背景补充] （可选）一句说为什么重要
```

**核实纠错型：**
```
I confirmed with [身份] that [结论]
[可选：对比被纠正的错误信息]
```

**分析引导型：**
```
[时间线] Last [month], Tesla announced X. In [month], Elon did Y.
[推断] This suggests Z.
[开放问题] What does this mean?
```

**极简标签型：**
```
[极简评论（3-5词）]
[配图/视频让画面说话]
```

## 用词风格

- 英语简单直接，无修辞堆砌
- 技术词汇自然使用（FSD Beta、HEPA、EFLOPS、AutoNavi），不解释，默认读者懂
- 具体到产品级别：Model 3 Highland、CyberCab、Wall Connector Gen 3
- 不用感叹号（偶有例外），平实客观
- 主动语态，句子结构简单
- 对比式陈述："X companies are 4-5 years behind Tesla in engineering, but better at understanding Chinese users"

## 标志性表达

| 句式 | 示例 |
|------|------|
| 消息来源引用 | "According to sources..." |
| 供应链人脉 | "A supply chain friend told me..." |
| 亲自核实 | "I confirmed with a Tesla China employee..." |
| 听说引入 | "I heard again today that..." |
| 时间线分析 | "Last June...In Feb. this year..." |
| 以问题结尾 | "What did he see?" |
| 极简评论 | "Its China Speed." |
| 纠错模式 | "the original poster was misleading" |

## 适合用 Chris Zheng 风格写的主题

- Tesla/EV 公司的内部动态和产品更新
- 自动驾驶/AI 汽车政策分析
- 中国科技公司在全球的竞争格局
- 供应链、产能、工厂扩张类爆料
- 监管政策对科技公司的影响
- 新能源车市场的竞争动态（比亚迪、小米、蔚来等）

## 写作时要避免的

- 不要长篇大论（此风格天然短平快）
- 不要用"关键是""值得注意的是"等套话
- 不要说未经核实的信息却写成已确认的语气
- 不要过于情绪化或使用夸张语言
- 不要隐藏信息来源（透明度是核心竞争力）
