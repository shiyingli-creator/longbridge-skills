---
id: lance-roberts
name: Lance Roberts (TalkMarkets / Real Investment Advice)
platform: TalkMarkets + realinvestmentadvice.com + Seeking Alpha
url: https://talkmarkets.com/contributor/lance-roberts/
topics: [macro trends, US equities, portfolio management, Fed policy, market cycles, risk management, technical + fundamental analysis]
language: English
---

# Lance Roberts 写作风格档案

## 背景

Chief Investment Strategist and Economist at RIA Advisors. Over 30 years of investment management experience. Publishes daily on Real Investment Advice and syndicated on TalkMarkets and Seeking Alpha. Host of the "Real Investment Show" radio program. Writes for sophisticated retail investors and professionals who want institutional-grade macro analysis delivered with clarity and conviction. Known for being data-driven, chart-heavy, and willing to take contrarian positions against the mainstream financial media narrative.

## 内容领域

- US equity market analysis (S&P 500, sector rotation, valuations)
- Macroeconomic trends (GDP, recession risk, inflation, employment)
- Federal Reserve policy and monetary analysis
- Portfolio strategy and risk management
- Market cycle analysis (full cycle investing, sector rotation)
- Credit markets and yield curve dynamics
- Behavioral finance and investor psychology

## 语气特征

- **Authoritative and data-anchored** — every claim is backed by charts, data points, or historical precedent
- **Contrarian by nature** — frequently challenges consensus views; comfortable being the "bear in the room"
- **Educating, not just opining** — explains the "why" behind every market call with economic logic
- **Long-form and thorough** — doesn't shy away from 2,000+ word analyses with multiple supporting charts
- **Candid about uncertainty** — "We don't know what happens next, but here's what the data suggests..."
- **Uses personal network references** — "My friend Eric Hickman of Kessler sent me an excellent note..."
- **Measured urgency** — calm and analytical even when delivering bearish or alarming conclusions
- **Value-oriented philosophical grounding** — explicitly references Hussman, Crestmont Research, etc.

## 文章结构

**Standard deep analysis format:**
```
1. Headline — takes a clear position ("Technically Speaking: Think Like a Bear, Invest Like a Bull")
2. Opening — frames the macro context or market event driving the piece
3. Chart/data presentation — specific indicators, ratios, or index levels cited with precision
4. Contrarian argument — why the consensus is wrong or incomplete
5. Historical analogy — references prior cycles (dot-com, 2008, etc.) as context
6. Portfolio implications — what investors should actually DO based on the analysis
7. Risk acknowledgement — what would invalidate the thesis
8. Conclusion — summarises the key position with conviction
```

## 用词风格

- Formal, precise financial language — "distributable income", "yield spread", "full market cycle"
- Uses specific index levels, percentages, and price targets
- References named economists, strategists, and research firms by name for authority
- Occasional vivid analogy: "more nauseating than the 418-foot drop of the Kingda Ka roller coaster"
- Block quotes from referenced experts embedded in the text
- Chart-reliant: frequently references "the chart below" or "as shown in the next chart"
- Cyclical framing: "full market cycles", "recessionary bottoms", "speculative excess"
- Never uses hype language — keeps a steady, serious register throughout

## 标志性表达

| 句式 | 示例 |
|------|------|
| Contrarian opener | "There is relatively little argument that [X is true]. However..." |
| Data anchor | "If we use a market cap/GDP ratio of 1.25 and an S&P 500 dividend yield of just 2%..." |
| Broken Clock concept | "This is what I have come to term the 'Broken Clock Syndrome.'" |
| Historical parallel | "As shown in the chart below, the sector rotation appears to lead the economic cycle." |
| Network reference | "My friend Eric Hickman of Kessler Investment Advisors sent me an excellent note..." |
| Bearish-but-balanced | "I too am a value-oriented investor... However, being a strict value investor can lead to mistakes when markets become driven by speculative excess." |
| Risk of certainty | "What we know, with almost absolute certainty, is that..." |
| Closing position | "The bottom line: [X] remains the most significant risk to portfolios in the near term." |

## 适合用 Lance Roberts 风格写的主题

- US equity market valuations and risk assessment
- Recession outlook and leading economic indicators
- Federal Reserve policy analysis
- Full market cycle positioning (sector rotation, defensive vs. cyclical)
- Behavioral investing mistakes (chasing performance, FOMO, recency bias)
- Long-form contrarian macro theses
- Portfolio risk management in late-cycle environments

## 写作时要避免的

- Don't write short or superficial takes — the style demands depth and supporting data
- Don't be bullish without nuance — Lance always acknowledges the bear case even in positive pieces
- Don't skip the charts/data references — the style is explicitly chart-dependent in structure
- Don't use hype, urgency, or FOMO language — the tone is calm and analytical
- Don't avoid naming specific indices, ratios, or price levels — precision is a core feature
- Don't ignore investor portfolio implications — every macro view must land with a "so what" for portfolios
