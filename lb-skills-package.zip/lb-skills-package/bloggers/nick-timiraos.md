---
id: nick-timiraos
name: Nick Timiraos
platform: X (Twitter) + WSJ
url: https://x.com/NickTimiraos
topics: [美联储, 货币政策, 宏观经济, 利率, 通胀, 就业数据]
language: 英文（可写中文版本）
---

# Nick Timiraos 写作风格档案

## 背景

华尔街日报（WSJ）首席经济记者，长期跑美联储口，被市场称为"美联储传声筒"（Fed Whisperer）。他的报道经常被解读为美联储在正式会议前向市场释放信号的渠道。每次重要 FOMC 会议前后，他的推文和文章会直接影响市场定价。

## 内容领域

- 美联储货币政策（加息/降息决策、前瞻指引）
- 宏观经济数据解读（CPI、PCE、非农就业、GDP）
- 美联储官员动向与表态
- 利率市场与债券
- 通胀路径与就业市场

## 语气特征

- **极度克制、中立、新闻式**——没有个人情绪，不表达明确立场
- **信息密度极高**，每句话都有信息量，没有装饰性语言
- **权威感来自消息来源**，而非观点本身："Fed officials are increasingly open to..."
- **精准用词**："consider"、"signal"、"lean toward"、"leave the door open"——每个动词都经过斟酌，因为市场会逐字解读
- 写作服务于信息传递，不服务于表达者本人
- 极少用第一人称，偶尔用"I'm told"表示消息来源

## 文章结构

**推文/短帖型（最常见）：**
```
[核心政策信号] 一句话
[官员立场/分歧] 具体描述
[背景/数据支撑] 1-2句
[市场影响/下一步] 可选
```

**WSJ 长文型：**
```
1. 导语：政策转变的核心信号（1句）
2. 官员动向与表态（具体姓名+措辞）
3. 经济数据背景（支撑或反驳当前路径）
4. 内部分歧与辩论（hawk vs. dove）
5. 市场反应
6. 下一个关键时间节点
```

## 用词风格

- **政策动词要精确**："signal"、"flag"、"lean"、"open to"、"consider"、"on track for"
- **避免绝对化**：不说"will cut"，说"could cut"、"appear set to"
- **引用官员原话**时用完整引号，不改写
- **数据精确到小数点**：2.4%、0.25个百分点、25bps
- **时间锚点**：September meeting、before year-end、at the next FOMC
- 不用行话堆砌，但金融术语（bps、PCE、dot plot）自然出现

## 标志性表达

| 句式 | 示例 |
|------|------|
| 政策信号式 | "Fed officials are increasingly open to cutting rates in September" |
| 分歧描述 | "Some officials worry that... while others argue..." |
| 消息来源 | "I'm told that..." / "according to people familiar with the matter" |
| 条件句 | "If inflation continues to ease, officials could..." |
| 留后门 | "...while leaving open the possibility of further increases" / "opens the door to..." |
| 官员表态引用 | 直接引用 Powell、Waller、Williams 等官员原话 |
| 数据定性 | "a surprisingly strong jobs report" / "inflation that has proved stickier than expected" |
| 内部分裂 | "Officials are divided on..." / "Fed officials are fracturing over..." |
| 意愿信号 | "signaled little appetite for..." / "leaning toward..." |
| 翻译Fed-speak | 引用官员原话后，附上自己对市场含义的白话翻译（这是他独有习惯） |

## 补充：一个被低估的核心习惯

Timiraos 有一个极其独特的操作：**引用官员讲话原文 → 立即附上自己的"翻译"**。例如他会引用 Powell 的措辞后写：*"Translation: We're likely getting a rate cut next month unless there's a dramatic change in the outlook."* 这种"引用+翻译"的双层结构是其他记者很少做的，也是他真正的市场影响力来源。

另外：他在**美联储静默期（blackout period）**照样能发出前瞻性报道，这使他的文章有独特的"时间窗口价值"——市场在官员无法发声时只能看他。

## 适合用 Nick Timiraos 风格写的主题

- 美联储利率决策分析
- 宏观经济数据解读（CPI、非农就业等）
- 央行政策走向（美联储、欧央行、日央行）
- 通胀/衰退路径分析
- 债券市场、利率市场动态

## 写作时要避免的

- 不要表达个人观点或情绪（他从不说"我认为"）
- 不要用夸张词汇（"暴跌"、"崩盘"、"疯涨"）
- 不要给出明确预测，要给概率和条件
- 不要缺少数据支撑，每个判断都要有锚点
- 不要用模糊的泛化表达，要具体到官员姓名和会议时间
