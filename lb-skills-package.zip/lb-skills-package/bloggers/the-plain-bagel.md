---
id: the-plain-bagel
name: The Plain Bagel (Richard Coffin)
platform: YouTube
url: https://www.youtube.com/@ThePlainBagel
topics: [金融教育, 投资原理, 个人理财, 金融产品解析, 投资心理]
language: 英文（可写中文版本）
---

# The Plain Bagel 写作风格档案

## 背景

加拿大 CFA 持证人 Richard Coffin 主持的金融教育 YouTube 频道。以"朴实、无噱头的金融教育"（plain, no-frills financial education）为定位，拒绝夸大标题党和情绪化内容。内容以解释金融概念、拆解投资产品、分析市场现象为主，兼顾深度与可及性。

## 内容领域

- 金融概念解释（债券、期权、ETF、对冲基金等）
- 投资心理与行为金融学
- 个人理财原则
- 金融产品利弊分析（指数基金 vs 主动管理、年金等）
- 市场现象解读（泡沫、崩盘、异常现象）
- 投资策略评估（价值投资、动量策略等）

## 语气特征

- **平静、理性、有教育感**——像一位你信任的理财顾问朋友
- **刻意去情绪化**：不用"暴跌"、"暴涨"、"必买"等词，用数据和逻辑说话
- **诚实承认不确定性**："It's hard to say for certain..."、"The evidence is mixed..."
- **两面分析**：几乎每个话题都会呈现 pros and cons，不给简单结论
- **幽默但克制**：偶尔有轻描淡写的加拿大式冷幽默，但不刻意搞笑
- 对"网红投资建议"保持健康的怀疑态度，但不刻薄

## 文章/视频结构

```
1. 开场：提出问题或概念（"Today we're going to talk about X"）
2. 概念定义：清晰解释这个东西是什么
3. 它如何运作（机制解析）
4. 支持它的理由（pros/evidence for）
5. 反对它的理由（cons/evidence against）
6. 现实情况/数据（实证研究或历史数据）
7. 结论：平衡的个人看法
8. 实践建议（如果适用）
```

## 用词风格

- 清晰、准确，避免不必要的行话
- 用了专业词汇一定解释
- 大量使用"however"、"on the other hand"、"that said"（平衡两面）
- 数据引用有来源：学术研究、历史数据、指数表现
- 不绝对化："tends to"、"generally"、"in most cases"
- 英式/加拿大式拼写习惯（偶尔）

## 标志性表达

| 句式 | 示例 |
|------|------|
| 概念引入 | "So what exactly is [X], and how does it work?" |
| 两面平衡 | "On one hand... On the other hand..." |
| 诚实限定 | "The evidence here is actually pretty mixed." |
| 研究引用 | "Studies have shown that..." / "Historically speaking..." |
| 怀疑网红建议 | "You might have seen this strategy promoted online, but..." / "If it sounds too good to be true, it probably is." |
| 平衡结论 | "Whether [X] is right for you depends on..." |
| 实践落地 | "If you do decide to [do X], here's what to keep in mind:" |
| 主动免责 | "Take everything you hear online with a grain of salt" |

## 补充：几个被遗漏的重要特征

1. **他对"Finfluencer"文化有鲜明的批判立场**：他明确区分"教育"和"建议"，并直接批评那些用"透明"作为借口推销激进观点的博主。这种**对同类创作者的批判性视角**是他独有的，也是他建立可信度的核心方式。档案中虽有"对网红建议保持怀疑"，但没有表达出他批评同行的力度。

2. **发布频率是bi-weekly（两周一更）**，不是高频博主。这意味着每个视频都经过精心打磨，内容密度高、结构更完整，与 Meet Kevin 的日更多更形成鲜明对比。这个节奏本身也是风格的一部分。

3. **他在做内容时非常注重"资质先行"**：他说"如果一开始就建立信任和资质，这会延续到未来"。他的 CFA/CFP 背景在内容中是隐性权威，不是显性炫耀，但他会在恰当时机提及。

4. **频道名"Plain Bagel"有专门典故**（播客中有3分钟专门讨论），强化了"朴实无华、拒绝噱头"的品牌定位，这个命名本身就是风格宣言。

5. **他也有 Dead on the Money 播客**，和YouTube频道内容有联动，写风格时可考虑播客文字稿的场景。

6. **档案整体准确，无明显错误。**

## 适合用 The Plain Bagel 风格写的主题

- 金融产品科普（ETF、债券、衍生品等）
- 投资策略的实证分析
- 行为金融学话题（锚定效应、过度自信等）
- 市场泡沫与非理性现象
- 个人理财原则
- 反驳流行但不靠谱的投资建议

## 写作时要避免的

- 不要给出简单的"买/不买"结论（他总是呈现两面）
- 不要用情绪化语言和夸张词汇
- 不要省略数据和研究支撑
- 不要装作一切都有明确答案（他会坦诚不确定性）
- 不要只讲理论，要有实际数据佐证
