---
id: trading-key
name: TradingKey
platform: Web (tradingkey.com) + App
url: https://www.tradingkey.com/
topics: [US stocks, global markets, macro analysis, thematic investing, crypto, commodities, IPOs]
language: English
---

# TradingKey 写作风格档案

## 背景

TradingKey is a multi-language financial media and data platform targeting retail investors across Southeast Asia and beyond. Its analysis articles are written by named analysts (e.g., Yulia Zeng) and cover global markets with a professional, research-house tone. Content is designed to feel institutional-grade but accessible — bridging the gap between Bloomberg-style depth and retail-friendly readability.

## 内容领域

- US and global equity analysis (thematic: AI, semiconductors, EVs, space, crypto)
- IPO previews and concept stock deep dives
- Commodities and metals (gold, silver, oil)
- Cryptocurrency analysis (BTC, ETH, Dogecoin)
- Macro / central bank policy
- Supply chain and sector-level analysis (Taiwan/US semiconductor chains, etc.)

## 语气特征

- **Professional but accessible** — reads like a sell-side research note simplified for retail
- **Thesis-driven**: every article opens with a clear investment thesis or key question
- **Quantitative anchoring**: always includes specific numbers, price targets, market caps, percentage moves
- **Balanced bull/bear framing**: presents both upside catalysts and downside risks
- **Forward-looking**: focuses on "what happens next" rather than just describing what happened
- **Authoritative without arrogance** — confident in claims but transparent about uncertainty
- **Multi-asset linkage**: connects equities to rates, FX, commodities, and macro

## 文章结构

**Standard deep-dive format:**
```
1. Headline — bold thesis + hook (e.g., "SpaceX IPO Nears: What Are SpaceX Concept Stocks?")
2. Opening paragraph — market context + why this matters now
3. Background / Company overview — what is X, why is it significant
4. Core thesis section(s) — numbered or sub-headered insights
5. Supply chain / ecosystem breakdown — who benefits, who is exposed
6. Risk factors — what could go wrong
7. Conclusion / Investor takeaway — actionable summary
```

## 用词风格

- Clean, professional English — no slang, minimal colloquial language
- Precise financial vocabulary: "market capitalisation", "earnings per share", "free cash flow yield"
- Bylined articles ("TradingKey", "Author: [Name]") — gives a sense of editorial credibility
- Uses company names with ticker symbols: "Apple (AAPL)", "NVIDIA (NVDA)"
- Sub-headers to segment long articles into clear themes
- Occasional rhetorical framing: "The real question is not X — it's Y"
- Data-forward: statistics and figures are embedded throughout, not just in conclusions

## 标志性表达

| 句式 | 示例 |
|------|------|
| Thesis opener | "Investing in SpaceX concept stocks is essentially a move to capture the certain growth of the commercial aerospace wave..." |
| Stakes framing | "The real question is not whether conflict begins. The real question is how long the disruption lasts." |
| Ecosystem framing | "A Full Review of Taiwan and U.S. Starlink Supply Chains" |
| Analyst attribution | "According to UBS, the safe-haven logic remains unchanged but is only delayed." |
| Multi-asset linkage | "If global interest rates are poised to rise, it will be difficult for U.S. equities to..." |
| Forward catalyst | "What key signals are being released?" |
| Balanced conclusion | "Both upside catalysts and downside risks remain in play for investors." |

## 适合用 TradingKey 风格写的主题

- Thematic stock analysis (AI, semiconductors, EVs, space, energy)
- IPO previews and concept stock identification
- Macro events and their impact on equities (Fed decisions, trade policy, geopolitics)
- Commodity and crypto analysis
- Supply chain deep dives (e.g., which companies benefit from X trend)
- Cross-asset market commentary

## 写作时要避免的

- Don't write in first person ("I think...") — use third-person or authoritative framing
- Don't skip the data — every claim needs a number to back it up
- Don't ignore downside risks — always include a balanced risk section
- Don't use informal language or colloquialisms — maintain a professional register
- Don't be vague about the investment angle — always tie back to "what does this mean for investors"
- Avoid overly long paragraphs — use sub-headers to break up analysis into digestible sections
