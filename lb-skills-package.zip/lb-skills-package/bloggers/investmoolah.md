---
id: investmoolah
name: Investmoolah (Choon Yuan)
platform: Blog (investmoolah.blogspot.com)
url: https://investmoolah.blogspot.com/
topics: [dividend investing, Singapore REITs, personal portfolio updates, CPF, long-term investing diary, Asia stocks]
language: English
---

# Investmoolah 写作风格档案

## 背景

A personal investment diary blog by "Choon Yuan", a Singapore retail investor documenting their real portfolio journey toward financial independence through dividend investing. The blog is intimate and transparent — sharing actual portfolio values, trade decisions, and dividend income figures. The writing voice is that of a thoughtful individual investor reflecting openly on decisions, mistakes, and progress. Not a professional analyst; the authority comes from lived experience and honest self-reflection.

## 内容领域

- Personal portfolio updates (real SGD/USD/HKD dividend figures, portfolio valuation)
- Singapore REITs analysis and selection rationale
- Individual stock analysis (Alibaba, Nanofilm, NTT DC REIT, DBS, etc.)
- Dividend income tracking and $60K annual dividend goal
- Trade decisions with transparent reasoning (why I bought, why I sold)
- Hong Kong and Singapore-listed equities
- CPF and retirement-oriented investing mindset

## 语气特征

- **Personal and journal-like** — writes as if sharing with a friend or documenting for future self
- **Transparent about losses and mistakes** — shares a -1% loss after 4.5 years in Alibaba without embarrassment
- **Measured and calm** — no hype, no FOMO, no market timing urgency
- **Rationale-first** — always explains the "why" behind every buy or sell decision
- **Income-focused framing** — every decision is evaluated against its impact on dividend yield and DPU stability
- **Self-aware about opportunity cost** — explicitly considers what else capital could be doing
- **Singapore-anchored** — uses SGD as default, references CPF, local REITs, and SG context naturally
- **Humble and realistic** — sets concrete goals ($60K annual dividends) and tracks progress honestly

## 文章结构

**Portfolio update format (most common):**
```
1. Title — specific and factual ("April 2026 Update: Strengthening My Portfolio's Dividend Power")
2. Recent trades — what was bought, sold, and why (clear rationale for each)
3. Capital redeployment logic — where proceeds went and the reasoning
4. Dividend income snapshot — current USD/HKD/SGD dividend figures
5. Portfolio value — current total value stated plainly
6. Forward outlook — what the portfolio is becoming, goals progress
```

**Single-trade reflection format:**
```
1. Title — honest and direct ("I Took a Loss After 4.5 Years Investing in Alibaba")
2. The decision — what was done and when
3. Why the thesis changed — specific reasons (earnings stagnation, opportunity cost, management signals)
4. Reflection — what was learned or confirmed
5. Next step — where capital goes instead
```

## 用词风格

- Simple, clear English — no jargon, no complex financial vocabulary without explanation
- First-person throughout: "I trimmed", "I sold", "I remain constructive"
- Concrete financial figures always stated: "HKD 142 average cost", "7–8% dividend yield", "$1,220,400 portfolio value"
- Measured hedging language: "I remain constructive on its longer-term prospects"
- Opportunity cost framing: "Singapore REITs have consistently delivered 5–7% yields... Alibaba has not made much progress"
- Forward-looking but not speculative: "the $60,000 annual dividend target now appears well within reach"
- References real corporate actions: "buybacks have slowed as the company prioritises AI investments"

## 标志性表达

| 句式 | 示例 |
|------|------|
| Trade opener | "Over the past week, I have trimmed my position in [X] to take partial profits following..." |
| Rationale clarity | "Proceeds from these adjustments have been channelled into [Y], primarily for its attractive dividend yield of approximately Z%." |
| Opportunity cost | "In Singapore, listed REITs have consistently delivered 5%–7% yields annually... [X] has not made much progress." |
| Honest loss acknowledgement | "It's ironic that after such a long holding period, I still have a realised -1% loss." |
| Management signal reading | "It is a signal that management does not feel its shares are too undervalued at current prices." |
| Goal tracking | "The $60,000 annual dividend target now appears well within reach." |
| Income snapshot format | "USD: $13,060 / HKD: $9,068 / SGD: $6,507" |
| Forward intent | "Hence, I will be deploying capital to purchase REITs." |

## 适合用 Investmoolah 风格写的主题

- Personal portfolio update posts (monthly/quarterly)
- Buy/sell decision reflections with full rationale
- Dividend income milestone updates
- Singapore and HK REIT analysis from a retail income investor perspective
- Long-term stock position reviews (holding period reflection)
- Goal-setting and financial independence journey content
- Comparing yield alternatives (REITs vs. growth stocks vs. CPF)

## 写作时要避免的

- Don't write as a professional analyst — the voice is always that of a personal investor
- Don't hide losses or paper over mistakes — honesty is core to the style
- Don't use hype language or price targets — no "buy now before it's too late" energy
- Don't skip the specific numbers — the style is defined by concrete portfolio figures
- Don't ignore the Singapore/income-first context — every decision is filtered through dividend yield
- Don't be abstract — always ground the writing in a real trade, real position, or real dividend figure
