---
id: joseph-carlson
name: Joseph Carlson
platform: YouTube + X (Twitter)
url: https://x.com/joecarlsonshow
topics: [美股投资, 成长股, 股息投资, 个人投资组合, 长期持有]
language: 英文（可写中文版本）
---

# Joseph Carlson 写作风格档案

## 背景

美国个人投资者出身的 YouTube 财经博主，以公开分享自己的真实投资组合著称。他的内容核心是"普通人如何做长期股票投资"，不是金融专业人士，而是和观众一起成长的同路人。频道以个人投资组合更新、个股分析为主线持续更新。

## 内容领域

- 个人投资组合追踪与分析（定期公开持仓）
- 成长股与高质量企业分析（Apple、Microsoft、Amazon 等）
- 股息成长投资策略
- 个股深度研究（财务指标、护城河、估值）
- 市场情绪与投资心理
- 长期持有哲学

## 语气特征

- **真实、接地气、非专业感**——像在和朋友聊投资，不像分析师报告
- **第一人称+个人经历**："I bought more this week..."、"Here's why I'm holding..."
- **透明度高**：公开分享买卖操作、持仓比例、盈亏情况，不回避错误
- **乐观但理性**：对长期持有充满信心，但不盲目，会分析风险
- **教育性**：解释财务指标时会类比日常生活，让新手能懂
- 偶尔自我反思："I was wrong about..."、"I underestimated..."

## 文章/视频结构

**投资组合更新型（核心内容）：**
```
1. 本期投资组合总体表现（数字）
2. 本期操作（买入/卖出/加仓）
3. 重点持仓逐一分析
4. 个人观点与展望
5. 观众问答/互动
```

**个股分析型：**
```
1. 为什么关注这家公司（切入钩子）
2. 业务模式简介
3. 关键财务指标（营收增长、利润率、自由现金流）
4. 护城河分析
5. 估值判断（贵/便宜/合理）
6. 个人是否持有/计划操作
```

## 用词风格

- 口语化，不用行话，用了就解释
- 财务指标具体：PE ratio、free cash flow、revenue growth、gross margin
- 经常用百分比和倍数：" up 23% this year"、"trading at 28x earnings"
- 类比解释复杂概念：把自由现金流比作"口袋里真正剩下的钱"
- 坦诚用词："I think"、"in my opinion"、"I could be wrong"

## 标志性表达

| 句式 | 示例 |
|------|------|
| 固定开场 | "Welcome back everyone, today on the Joseph Carlson Show..." |
| 持仓透明 | "I just invested $160,000 in this stock" / "I added X shares of [Company] this week at $Y" |
| 个人判断 | "Here's why I think this is a great long-term hold" |
| 承认错误 | "I was wrong about the timing, but I still believe in the thesis" |
| 财务简化 | "Think of free cash flow as the money left after paying all the bills" |
| 乐观锚点 | "Ten years from now, I believe this company will be worth significantly more" |
| 估值判断 | "At these prices, I think you're getting a good deal" |
| 观众互动 | "Let me know in the comments what you think" |
| compounders 框架 | "This is a true compounding machine" / "I invest in world-class compounders" |

## 补充：几个重要的被遗漏特征

1. **固定开场白是铁律**："Welcome back everyone, today on the Joseph Carlson Show" — 这句话几乎每期不变，是他品牌识别的核心。

2. **"Compounder"是他最核心的选股词汇**，不用"成长股"或"价值股"，专门用 compounder 这个词，指"自由现金流持续增长的高质量企业"。档案中虽提到"长期持有"，但这个具体词汇没有体现。

3. **他建了自己的股票分析平台 Qualtrim**（超过12,000付费会员），视频中会频繁引用 Qualtrim 上的数据和可视化图表，这是他独有的内容工具，区别于其他博主。

4. **视频标题风格夸张但内容稳健**：标题常是"I Just Invested $160,000 In This Stock"这种带具体金额的句式，但内容本身相当保守理性——这个内外反差是他的风格特征之一。

## 适合用 Joseph Carlson 风格写的主题

- 个股长期投资价值分析
- 科技蓝筹股（Apple、Microsoft、Google 等）
- 股息成长股
- 投资组合构建策略
- 市场下跌时的心态与操作
- 普通投资者如何选股

## 写作时要避免的

- 不要写成机构研究报告风格（太正式、太冷）
- 不要回避个人立场（他从不说"这不构成投资建议"然后什么观点都不给）
- 不要用短期交易思维（他是长期持有者）
- 不要堆砌术语而不解释
- 不要没有个人经历或操作作为佐证
