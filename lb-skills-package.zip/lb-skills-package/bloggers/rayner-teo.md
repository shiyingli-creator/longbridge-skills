---
id: rayner-teo
name: Rayner Teo
platform: X (Twitter) + Blog (TradingwithRayner.com)
url: https://x.com/Rayner_Teo
topics: [技术分析, 交易策略, 风险管理, 趋势跟踪, 交易心理]
language: 英文（可写中文版本）
---

# Rayner Teo 写作风格档案

## 背景

新加坡全职交易者和交易教育博主，TradingwithRayner.com 创始人。从普通上班族转型为全职交易者，以亲身经历构建内容权威性。以技术分析教育为核心，风格极度实用，专注于"可以立即执行的交易知识"。

## 内容领域

- 技术分析（趋势线、均线、支撑阻力、形态）
- 交易策略（趋势跟踪、突破交易、均值回归）
- 风险管理（仓位管理、止损设置、风险收益比）
- 交易心理（纪律、情绪控制、连续亏损后的心态）
- 外汇、股票、期货市场的图表分析

## 语气特征

- **直接、务实、无废话**——每篇文章都有明确的可操作结论
- **简单到极致**：用最简单的语言解释复杂概念，像在辅导学生
- **步骤化**：几乎所有内容都拆解成 numbered steps（第1步、第2步…）
- **反套路**：经常先破除常见误区，再给出正确方法
- **亲身经历背书**："When I was starting out, I made this mistake..."
- **不卖弄**：不炫耀收益，强调方法论的可重复性

## 文章结构

**教程型（核心内容）：**
```
1. 标题直接说结论（"How to [do X] in [Y] steps"）
2. 开场：这个问题为什么重要（1段）
3. 常见误区（"Most traders think X, but they're wrong"）
4. 正确方法（分步骤，每步配图/例子）
5. 实战示例（图表或案例）
6. 总结（3-5条 takeaways）
7. 行动问题（"What's your approach to X? Let me know below."）
```

**推文型：**
```
[反直觉开场] "Most traders do X. It's wrong."
[正确做法] "Here's what actually works:"
[分点列举] 3-5条简短要点
[行动号召] "Save this for later."
```

## 用词风格

- 短句，多用句号，少用逗号
- 大量使用数字列表："Here are 3 reasons..."
- 直接命令式：" Set your stop loss below..."、"Look for..."、"Avoid..."
- 简单词汇：不用"utilize"，用"use"；不用"implement"，用"do"
- 图表语言：higher highs、higher lows、breakout、pullback、support/resistance

## 标志性表达

| 句式 | 示例 |
|------|------|
| 个人故事开场 | "When I was in university, a forex broker came to my school..." |
| 反直觉开场 | "Most traders think [X]. Here's why they're wrong." |
| 步骤引导 | "Here's how to [do X] in 3 simple steps:" |
| 亲身经历 | "When I was starting out, I made this exact mistake." |
| 误区破除 | "The truth is..." / "The reality is..." |
| 简洁总结 | "Here's the bottom line:" |
| 互动收尾 | "What do you think? Leave a comment below." |
| 保存提示 | "Save this post. You'll need it." |
| 量化规则 | "Risk no more than 1-2% per trade." |
| 直接命令 | "Identify support and let the price come to it." / "And that's it!" |

## 补充：一个被遗漏的重要开场模式

档案记录的"反直觉开场"是对的，但**还有一种同样常见的开场**：**个人失败故事**。他经常以"我在大学时，一个外汇经纪人来到我们学校……我的账户亏损了50%"这样的亲身遭遇作为开场，目的是建立"我跟你一样曾经是个输家"的共鸣基础，然后引出"但我后来学会了……"。这两种开场轮流使用。

另一个值得补充的特征：他写作极其**口语化，常用感叹词收尾**，如"And that's it!" 这种简短的句子在步骤列举后频繁出现，制造一种"交易其实很简单"的轻松感。

## 适合用 Rayner Teo 风格写的主题

- 技术分析方法讲解
- 交易策略入门与进阶
- 止损/仓位管理教程
- 图表形态解读
- 交易心理与纪律
- 常见交易错误与纠正

## 写作时要避免的

- 不要写得像学术论文（他的读者是散户交易者）
- 不要长段落（要短句+列表）
- 不要只讲理论，每个概念都要配具体操作步骤
- 不要模糊化（要给具体数字：止损放在X处、风险比例1-2%）
- 不要省略"为什么"——每个规则都要解释背后原因
