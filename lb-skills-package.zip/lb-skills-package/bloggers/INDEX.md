# 博主风格库索引

> 每次新增博主，在此更新索引。

| ID | 博主 | 平台 | 内容领域 | 语言 | 文件 |
|----|------|------|---------|------|------|
| `lenny` | Lenny Rachitsky | Substack Newsletter | 产品管理、增长、职业发展、AI工具 | 英文/中文 | [lenny-rachitsky.md](lenny-rachitsky.md) |
| `chris-zheng` | Chris Zheng (@ChrisZheng001) | X (Twitter) | Tesla中国、EV市场、自动驾驶、供应链 | 英文/中文 | [chris-zheng.md](chris-zheng.md) |
| `nick-timiraos` | Nick Timiraos | X + WSJ | 美联储、货币政策、宏观经济、利率、通胀 | 英文/中文 | [nick-timiraos.md](nick-timiraos.md) |
| `joseph-carlson` | Joseph Carlson | YouTube + X | 美股长期投资、成长股、个人投资组合 | 英文/中文 | [joseph-carlson.md](joseph-carlson.md) |
| `rayner-teo` | Rayner Teo | X + Blog | 技术分析、交易策略、风险管理、交易心理 | 英文/中文 | [rayner-teo.md](rayner-teo.md) |
| `xiao-lin-shuo` | 小lin说 | YouTube | 财经科普、宏观经济、商业故事、历史经济事件 | 中文 | [xiao-lin-shuo.md](xiao-lin-shuo.md) |
| `meitou-meiguu` | 美投讲美股 | YouTube | 美股个股分析、财报解读、估值、市场热点 | 中文 | [meitou-meiguu.md](meitou-meiguu.md) |
| `the-plain-bagel` | The Plain Bagel (Richard Coffin) | YouTube | 金融教育、投资原理、个人理财、行为金融学 | 英文/中文 | [the-plain-bagel.md](the-plain-bagel.md) |
| `meet-kevin` | Meet Kevin (Kevin Paffrath) | YouTube | 美股热点快评、宏观经济新闻、美联储、个人投资 | 英文/中文 | [meet-kevin.md](meet-kevin.md) |
| `sg-stocks-investing` | SG Stocks Investing | Blog | Singapore REITs, SGX stocks, Singapore property, CPF, dividend investing | English | [sg-stocks-investing.md](sg-stocks-investing.md) |
| `trading-key` | TradingKey | Web + App | US/global equities, thematic investing, IPOs, crypto, commodities, macro | English | [trading-key.md](trading-key.md) |
| `lance-roberts` | Lance Roberts (TalkMarkets / RIA Advisors) | TalkMarkets + Blog | Macro trends, US equities, Fed policy, market cycles, portfolio risk management | English | [lance-roberts.md](lance-roberts.md) |
| `michael-kramer` | Michael J. Kramer (TalkMarkets / Mott Capital) | TalkMarkets + Investing.com | Options market structure, VIX/gamma mechanics, S&P 500 daily analysis, rates, volatility | English | [michael-kramer.md](michael-kramer.md) |
| `investmoolah` | Investmoolah (Choon Yuan) | Blog | Singapore REITs, dividend investing, personal portfolio diary, HK/SG stocks | English | [investmoolah.md](investmoolah.md) |
| `investnotbet` | InvestNotBet | Blog | Long-term investing, US stock analysis, avoiding trading traps, ETFs, crypto, geopolitical risk | English | [investnotbet.md](investnotbet.md) |
| `fifth-person` | The Fifth Person | Blog + YouTube | Value-growth investing, Singapore/Asian REITs, financial literacy, dividend portfolios | English | [fifth-person.md](fifth-person.md) |

---

## 自主选择博主的规则

当用户未指定博主风格时，根据主题自动匹配最合适的博主：

| 主题类型 | 优先博主 | 理由 |
|---------|---------|------|
| Tesla、EV、自动驾驶、新能源、供应链 | `chris-zheng` | 他的主场，爆料+内部消息风格 |
| 美联储、货币政策、利率、CPI、通胀数据 | `nick-timiraos` | "美联储传声筒"，政策分析权威 |
| 产品策略、增长、PM职业、AI工具、创业、平台战略 | `lenny` | 深度框架拆解，适合科技公司战略分析 |
| 美股个股长期投资分析（蓝筹/成长股） | `joseph-carlson` | 个人投资组合视角，compounder框架 |
| 技术分析、交易策略、止损、图表形态 | `rayner-teo` | 交易教育专家，步骤化实战风格 |
| 宏观经济科普、金融历史故事、企业兴衰叙事 | `xiao-lin-shuo` | 故事化+类比，适合科普向深度内容 |
| 美股个股财报解读、估值分析（中文受众） | `meitou-meiguu` | 数据驱动，面向中文美股投资者 |
| 金融概念科普、投资产品利弊分析、行为金融 | `the-plain-bagel` | 平衡两面，实证研究，反网红建议 |
| 市场突发热点快评、美联储数据即时解读、高能量观点 | `meet-kevin` | 速度第一，直接预测，高频更新风格 |
| 其他科技/商业话题 | 根据内容调性判断（偏教育→`the-plain-bagel`，偏观点→`meet-kevin`，偏叙事→`xiao-lin-shuo`） | — |
| Singapore REITs, SGX stocks, Singapore property, CPF | `sg-stocks-investing` | SG-anchored retail investor lens, practical "what this means for you" framing |
| Global thematic equities, IPO analysis, supply chain deep dives, crypto/commodities, cross-asset | `trading-key` | Institutional-grade research tone, data-rich, multi-asset linkage |
| US macro, recession risk, Fed policy, full market cycle portfolio strategy, contrarian bear case | `lance-roberts` | Chart-driven, value-oriented, long-form contrarian macro thesis |
| S&P 500 daily mechanics, options/VIX/gamma/vanna, liquidity stress, volatility regime | `michael-kramer` | Options market structure expert, blunt and punchy daily commentary |
| Personal dividend portfolio updates, SG/HK REIT income diary, long-term buy/sell reflections | `investmoolah` | Intimate personal investor diary, transparent actual figures, income-first framing |
| Long-term investing education, debunking hype stocks, avoiding trading traps, risk-first stock analysis | `investnotbet` | Calm and independent, experience-backed, anti-gambling framing |
| Value-growth stock analysis (SG/Asia/US), REIT fundamentals, financial literacy, dividend portfolio building | `fifth-person` | Award-winning SG investment platform, warm + evidence-based, community-oriented |
