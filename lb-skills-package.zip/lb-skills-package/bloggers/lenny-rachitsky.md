---
id: lenny
name: Lenny Rachitsky
platform: Newsletter (Substack) + Podcast
url: https://www.lennysnewsletter.com
topics: [产品管理, 增长策略, 职业发展, AI工具, 创业]
language: 英文（可写中文版本）
---

# Lenny Rachitsky 写作风格档案

## 背景

前 Airbnb 产品负责人，运营 Substack 上订阅量最大的科技 Newsletter（110万+ 订阅）。自我标签：writing · angel investing · advising。

## 内容领域

- 产品管理与增长框架（Product & Growth）
- 职业发展与求职（Career）
- AI 在产品工作中的应用（AI for PMs）
- 创业公司运营实战

## 语气特征

- **像写给朋友的信**，而不是企业报告
- 第一人称大量使用："I generally found..." / "My take is..."
- 直率但不傲慢，默认读者是聪明的从业者
- 愿意承认不确定性，不把观点当真理
- **无废话**：结论先行，解释在后
- 标志性开场：可模仿 "Let me share what I've learned..." 或 "Here's the thing:"

## 文章结构

```
1. 读者痛点/具体问题（1-2句钩子）
2. 核心结论（直接给答案）
3. 问题背景（为什么这很重要）
4. 可命名框架（The XXX Model / The XXX Loop）
5. 逐步分解 + 真实公司案例（Airbnb、Duolingo、Figma 等）
6. 数据支撑（调研数字、百分比）
7. 可操作行动建议（"Three things you can do tomorrow:"）
8. 简洁收尾（回扣开头或提出问题）
```

## 用词风格

- 短句为主，偶有长句但不堆砌
- 大量使用粗体标题 + 短段落（提高可扫描性）
- 用具体公司名和真实数字，不说"某科技公司"
- 量化结论："58% reply rate" / "top 2 companies" / "median 10 hours"
- 框架命名："The Magic Loop" / "The Waterline Model" / "Strategy Blocks"

## 标志性表达

| 句式 | 示例 |
|------|------|
| 结论先行 | "Fintech was dominant. Here's why..." |
| 引出数据 | "Here's what I found..." / "The data shows..." |
| 承认例外 | "...with a few surprising exceptions" |
| 制造悬念 | "The top two were not who you'd expect" |
| 框架命名 | "I call this the Magic Loop" |
| 真实案例 | "At Airbnb, we did..." / "Duolingo's approach is..." |
| 对读者提问 | "What's your biggest challenge this week?" |
| 数字标题 | "7 habits..." / "25 proven tactics..." / "50 ways..." |

## 典型文章示例结构

> **标题**："The operator's guide to product strategy"
>
> **开场**：Most PMs struggle with strategy because they've never seen a good one. Here's a framework I've been refining for years.
>
> **框架**：I call this the Strategy Blocks model. It has four parts: [1] [2] [3] [4]
>
> **案例**：When I was at Airbnb, we used this to decide...
>
> **数据**：In my survey of 200+ PMs, 73% said strategy was their #1 gap.
>
> **行动建议**：Three things you can do this week: ...
>
> **收尾**：Strategy isn't magic. It's just a clear answer to: what are we NOT doing?

## 适合用 Lenny 风格写的主题

- 公司产品策略分析（某公司的增长飞轮）
- AI 工具改变行业的深度解读
- 职场/管理类话题
- 科技公司经营模式拆解
- 数据驱动的行业洞察

## 写作时要避免的

- 不要写得像咨询报告（避免"首先其次最后"）
- 不要模糊泛化（要具体公司、具体数字）
- 不要只讲方法论，要有真实案例
- 不要结论在最后才出现
