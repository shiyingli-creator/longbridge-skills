---
name: sg-market-news
description: >
  每日搜索并汇总新加坡股市、宏观经济政策的重要新闻，按重要程度筛选，
  生成双语（中英）市场简报；用户追加港美股关注事件后，自动生成完整的
  英文社区讨论帖子（含标题、摘要、正文、3大问题、市场回顾）。支持中英文触发。
  触发词：新加坡市场新闻、今天新加坡股市、SG market news、Singapore market update、
  给我新加坡新闻、daily SG briefing、新加坡今日要闻、sg-market-news。
  当用户想了解新加坡股市、宏观经济、上市公司动态，或在SG简报基础上生成社区讨论帖时，必须使用此skill。
---

# SG Market News Skill

三阶段工作流：
- **Phase 1**：搜索并汇总当日新加坡市场新闻，输出双语简报
- **Phase 2**：用户追加港美股事件后，合并所有信息，生成完整英文社区讨论帖
- **Phase 3**：自动生成 5 个新加坡散户视角的社区互动帖（可选 1 个为博主风格）

## 依赖说明

- **必需工具**：`web_search` 和 `web_fetch`（Phase 1 抓取新闻所需）
- **配套 Skill**：`blogger-writer`（Phase 3 博主风格帖会引用其博主索引 `/mnt/skills/user/blogger-writer/INDEX.md`）。若未安装，Phase 3 仍可运行，但博主风格帖会自动回退为第 5 个散户视角帖。
- **运行环境**：建议使用支持联网搜索的 Claude（claude.ai 或带 web 工具的 API 配置）

---

## Phase 1：新加坡市场简报

### Step 0：确认当日日期

**用户每天会在对话开头告知当日日期（如"给我今天 2026年5月21日 周四的新加坡市场新闻"）。必须提取该日期，并在所有搜索 query 中用具体日期替换 "today"。**

- ✅ 正确：`SGX listed companies earnings results May 21 2026`
- ❌ 错误：`SGX listed companies earnings results today`

事件日历搜索同理，用具体的"月份+年份"而非模糊词：
- ✅ 正确：`US economic calendar week of May 19 2026`
- ❌ 错误：`US economic calendar this week`

---

### Step 1：并行搜索（11条）

同时执行以下搜索，覆盖所有关键领域。**所有 query 中的日期占位符须替换为用户告知的实际日期。个股搜索最重要，务必多搜**：

> **强制拉新原则**：个股相关的搜索 query（第4–9条）必须在末尾加上 `"[Month DD YYYY]" OR "[Month DD-1 YYYY]"`（即当日和前一交易日日期），强制搜索引擎优先返回最新结果，避免相关性排名把上周/上月的旧财报置顶。

**宏观 / 政策（3条）**
1. `Singapore economic policy MAS announcement [Month DD YYYY]`
2. `Singapore property HDB market news [Month DD YYYY]`
3. `Singapore GDP trade inflation news [Month YYYY]`

**个股动态（6条）— 重点**
4. `SGX listed companies earnings results [Month DD YYYY]`
5. `Singapore listed company contract win acquisition [Month DD YYYY]`
6. `Singapore listed company CEO CFO director change [Month YYYY]`
7. `Singapore REIT distribution results [Month YYYY]`
8. `Singapore blue chip DBS OCBC UOB SIA Singtel results news [Month DD YYYY]`
9. `SGX company announcement corporate action [Month DD YYYY]`

**事件日历（2条）— Key Events 必搜，不可省略**
10. `Singapore economic calendar CPI GDP MAS data release week of [Month DD YYYY]`
11. `US economic calendar jobless claims PMI Fed speakers FOMC week of [Month DD YYYY]`

这两条搜索结果专门用于填充 Phase 2 帖子的「📅 Key Events Tonight / This Week」板块，确保覆盖：
- 美国本周重要经济数据（Jobless Claims、CPI、PMI、非农等）及 Fed 官员发言
- 新加坡本地数据发布时间（CPI、GDP、MAS 政策声明）
- 重大企业事件（已知财报日期、IPO、重要发布会）

对搜索结果中出现的具体公司，**使用 web_fetch 抓取原文页面**以获取更完整的数据（股价、具体金额、百分比等）。

> **日期核查（抓取后立即执行）**：每篇文章抓取完毕后，第一步必须读取文章的发布日期（页面顶部的 byline 日期、URL 中的日期、或文内时间戳）。发布日期早于前一交易日（即超过 1 个交易日）的文章，**无论内容多相关，直接丢弃，不得纳入简报**。记录被丢弃的文章公司名，防止"好像找到了新航/DBS"但其实是旧财报的情况。

**可信来源白名单**（优先抓取，排除其他）：

*本地媒体*
- The Business Times (businesstimes.com.sg) — 首选，moomoo News SG 主要引用来源
- The Straits Times (straitstimes.com)
- Channel NewsAsia / CNA (channelnewsasia.com)

*官方机构*
- SGX (sgx.com) — 官方公告、月度市场数据
- MAS (mas.gov.sg) — 货币政策、通胀数据
- HDB (hdb.gov.sg) — 房产数据
- MTI (mti.gov.sg) — GDP、贸易数据
- DOS (singstat.gov.sg) — 统计数据

*财经聚合 / 数据*
- SGinvestors.io — SGX公告聚合，用于发现个股新闻线索
- ShareInvestor (shareinvestor.com) — STI点位、市场数据
- moomoo News SG (moomoo.com/community) — 参考选题方向，不直接引用

*国际媒体（新加坡相关报道）*
- Reuters Singapore
- Bloomberg Singapore

### Step 2：筛选与评分

从搜索结果中筛选新闻，按以下标准打分，**总计不超过10条**：

| 优先级 | 类型 | 示例 |
|--------|------|------|
| ⭐⭐⭐ 高 | 政策/央行/MAS声明、重大财报（蓝筹股）、并购 | MAS加息、DBS季报 |
| ⭐⭐ 中 | 中型公司财报、高管变动、大额合同、REIT分派 | REITs季度业绩、CEO离职 |
| ⭐ 低 | 小公司动态、分析师评级调整 | 小市值股票评级 |

**数量目标**：
- 🇸🇬 Breaking News：1–3条（宏观/政策，质量优先）
- 🔔 Stocks to Watch：**5–8条**（个股为主体，尽量覆盖不同板块）
- 合计不超过10条

**过滤规则**：

- **时效范围**：优先收录当日新闻；前一交易日收盘后发布的新闻（如盘后财报、盘后公告）同样可收录，但超过1个交易日的旧闻一律排除。**每条新闻在纳入前必须已通过"日期核查"步骤确认发布日期**，不得仅凭标题或摘要判断时效性。若无法确认发布日期，该条新闻不收录。

- **核心原则：每个热点默认只展示1天**。一个事件在某日简报/帖子中出现过后，次日起**默认不再收录**，除非满足下方"再次收录条件"。这是为了避免社区帖子重复，保持每日新鲜感。

  *再次收录条件*（满足任一即可）：
  - **结果落地**：从"预期/传闻/拟议"进入"确认/落地"阶段。例：拟收购 → 完成交割、传闻加息 → MAS正式宣布
  - **进展更新**：事件本身有新的实质性进展。例：贸易谈判昨天提及但未达成，今天有新协议草案
  - **数据修正**：核心财务数据被修正，或出现重大反转
  - **市场反应剧烈**：财报次日股价异动超过 ±5%、出现监管/官方回应、引发同行业连锁反应
  
  *判断示例*：
  - ❌ "DBS 今天发了财报，明天再讲一遍财报内容" → 重复，不收录
  - ✅ "DBS 财报次日股价跌 7%、分析师下调评级" → 是市场新反应，可收录
  - ❌ "特朗普访华行程消息昨天已发" → 重复，不收录
  - ✅ "特朗普访华今天有新的协议草案/联合声明" → 是新进展，可收录
  - ❌ "MAS 上周已宣布的政策" → 旧闻，不收录
  - ✅ "MAS 政策落地后首份通胀数据出炉" → 是后续数据点，可收录

  **执行方式**：生成 Phase 1 简报或 Phase 2 帖子前，回顾最近1-2个工作日已发布的简报（如有记忆/上下文），逐条核查是否构成重复。无法核查时，对"看起来眼熟"的事件（尤其是大公司财报、宏观政策）保持警觉，优先采用"是否有新进展"作为筛选标准。

- 排除重复新闻（同一事件只保留最权威来源）
- 排除非新加坡核心来源的消息
- Catalist小市值股票：仅收录有实质性事件（财报、合同、高管变动）的，不收录纯行政公告

### Step 3：分类整理

**板块A：🇸🇬 Breaking News**
- 宏观经济、政策、房产、MAS、政府数据
- 每条包含：核心数据点、背景、市场影响

**板块B：🔔 Stocks to Watch**
- 个股动态：财报、合同、高管变动、诉讼、并购
- 每条必须包含：股票代码（格式见下方）、价格变动

---

### Step 3.5：输出前审核（不可跳过）

在输出任何内容前，对所有待收录条目逐一过一遍以下清单，不通过的条目**直接删除**，不保留、不降级：

**① 日期核查**
- 该条新闻的发布日期是否已通过 Step 1 日期核查？
- 发布日期是否在"当日"或"前一交易日收盘后"范围内？
- ❌ 未能确认日期 → 删除
- ❌ 发布超过 1 个交易日 → 删除

**② 来源核查**
- 该条新闻是否来自白名单来源（BT、ST、CNA、SGX、MAS、HDB、MTI、DOS、SGinvestors、ShareInvestor、Reuters SG、Bloomberg SG）？
- ❌ 来源不在白名单 → 删除

**③ 内容核查**
- 该条新闻的核心数据（涨跌幅、财报数字、合同金额）是否有原文支撑，还是推断/估算？
- ❌ 核心数据无原文支撑 → 删除该数据或整条删除
- 该条描述是否与原文一致，有没有夸大或缩小事件性质？
- ❌ 描述失实 → 修正或删除

**④ 重复性核查**
- 该事件是否在近 1–2 个工作日内已发布过，且不满足"再次收录条件"？
- ❌ 重复旧事件 → 删除

**⑤ 跨日连续出现核查（不可跳过，今日新增强制检查）**

在输出前，逐条问自己：**"这条内容昨天是否已经出现过？"**

- 回顾本次对话上下文中已输出的 Phase 1 / Phase 2 内容，逐条比对
- 若某条目昨日已出现，且今日**没有满足以下任一条件**，直接删除，不得以"重要"为由保留：
  - 结果落地（拟议 → 确认）
  - 实质新进展（新数据、新公告、新协议）
  - 市场反应剧烈（股价异动 ±5%+、监管介入、行业连锁反应）

**典型错误示例（禁止重蹈）：**
- ❌ FLCT 收购 5月25日公告 → 5月26日收录 → 5月27日无新进展却再次出现 → **应删除**
- ❌ SG GDP/CPI 数据 5月25日发布 → 5月27日（2个交易日后）仍收录 → **应删除（超时效）**
- ✅ DBS 财报昨日发布 → 今日股价异动 -7% → **可作为新的市场反应条目收录**

**执行要求**：不得因"今天没有足够新闻"而降低标准、放行重复内容。宁可简报条数少，不收录过期或重复条目。

审核完毕后，在内部记录一行简短的审核结论（不输出给用户），格式：
> `审核通过：X 条（已删除 Y 条，原因：[日期过期/来源不符/数据无据/重复/跨日重复]）`

若审核后剩余条目少于 3 条，主动说明："今日符合时效和来源要求的 SG 新闻较少，仅收录 X 条。"

---

### Step 4：输出 Phase 1 简报

格式见下方「Phase 1 输出模板」。

**输出完毕后**，主动提示用户：
> "简报已完成 ✅ 如需生成社区讨论帖，请继续输入今日港股 / 美股的关注事件，我将合并整理为完整帖子。如有盘前简报，也可一并附上，我会同步整合进 SG 板块。"

---

## Phase 2：社区讨论帖生成

**触发条件**：用户在 Phase 1 简报完成后，追加输入港股或美股的事件、数据或要点。用户也可同时附上**盘前简报**（含 SG 个股关注、隔夜情绪、油价、大宗商品等数据）。

> **盘前简报处理规则**：若用户附上盘前简报，Phase 2 须将盘前简报内容与用户追加事件合并整合，优先补入 Phase 1 未覆盖的个股和数据点（如盘中大跌标的、能源敏感标的、领导层变动、具体油价/汇率数字等），避免遗漏重要市场信息。盘前简报中的个股同样须通过 Step 0 市场归属核验后方可纳入。

### Step 0：输入核验（生成帖子前必须执行）

在整合内容前，先对用户输入的所有标的进行市场归属核验：

**保留**：
- 🇺🇸 美股（NYSE / Nasdaq / AMEX 上市）
- 🇭🇰 港股（HKEX 上市，股票代码为数字.HK）
- 🇸🇬 新加坡股（SGX 上市）

**摘除**：
- 🇨🇳 A股（沪深两市上市，股票代码为6位数字，交易所为 SSE / SZSE）
- 任何仅在中国大陆市场上市的标的（包括北交所）

> 注意：同一公司若同时有港股和A股（如腾讯、比亚迪），**保留港股部分，摘除A股部分**。若用户输入的是A股事件但该公司有港股，自动转换为港股视角处理。

核验完成后，**不需要向用户列出被摘除的标的**，直接用保留的内容生成帖子。

### 整合逻辑

将以下内容合并为一篇帖子：
1. Phase 1 已整理的新加坡新闻（宏观 + 个股）
2. 用户输入中**核验保留**的港美股事件

**整合前必做：跨日重复检查**
回顾本次对话中已输出的内容，对每一条 SG 新闻再过一遍 Step 3.5 的⑤项检查。昨日已出现、今日无实质新进展的条目，在 Phase 2 中同样不得出现。宁可 SG 板块内容少，不收录重复条目。

### 帖子写作原则

- **语言**：全英文
- **语气**：活泼、有观点、像一个熟悉全球市场的投资者朋友在聊天，不是机构报告
- **目标**：吸引社区用户互动评论，问题要有争议性或开放性，让人忍不住想回答
- **精简但有料**：正文导语控制在5句以内，突出最重磅的2–3个事件
- **3大问题**：每个问题必须跨越"事实描述"，聚焦"判断/预测/策略"，让读者真正需要思考才能回答；问题质量检验：读者应能说出一个具体的立场或策略，而不只是复述新闻
- **市场回顾**：按 🌍 Global → 🇺🇸 US → 🇸🇬 SG → 🇭🇰 HK/China 分区块，顺序固定不得改变，每区块3–6句，有数据支撑

### Phase 2 输出模板

**格式说明**：
- 项目符号统一使用 `●`（U+25CF，实心圆点）
- 公司名、关键数据（涨跌幅、数字）、重要事件词汇加粗；指数行整行加粗

**Key Events 编写规则（每次必须执行）**：

Key Events 是一个**纯粹的未来事件清单**，只收录尚未发生的事件。正确操作只有一个动作：**在昨日未发生的条目基础上，追加今日新发现的待跟进事件。**

执行步骤：
1. 从上一次 Phase 2 的 Key Events 中，取出**所有尚未发生**的条目（已发生的不用管，它们自然不再是"未来事件"）
2. 将今日搜索/用户输入中发现的新待跟进事件**追加**进去
3. 若某持续性事件有新进展（如 SpaceX IPO 出现新消息），更新该条描述
4. 输出合并后的完整列表

**禁止的操作**：
- ❌ 不得从零开始重新生成 Key Events（会丢失昨日结转的事件）
- ❌ 不得"主动删除"任何条目（过期的事件自然就不是未来事件，无需删除动作）
- ❌ 不得因为"今日没搜到相关新闻"就把昨日结转的条目漏掉

**跨市场重复标的处理**：
同一公司若在多个市场挂牌（如 NIO 同时有 NYSE / HKEX / SGX 挂牌），只在**最相关的一个板块**提及，其余板块不重复。
- 判断依据：事件发生在哪个市场 → 放在对应板块；若是港股/美股财报，放 HK 或 US 板块，SG 板块不再重复
- SGX 挂牌的海外股 USD OV（如 NIO.SG、Alibaba.SG）通常是二次上市，不作为独立提及依据

```
☕️ [Task Coins Giveaway] Daily Market Talk

🇺🇸🇭🇰🇸🇬 Big moves across US, HK, SG markets. Join the chat & earn Task Coins!

[导语：2–3句，点出当日最重磅的2–3个跨市场事件，语气轻松有力，以"Midday update:"开头，不铺陈背景，直接说事]

💬 Today's 3 Big Questions
1. [事件背景 — 核心判断/策略问题？]
2. [事件背景 — 核心判断/策略问题？]
3. [事件背景 — 核心判断/策略问题？]

👇 Like, drop your take (20+ words), click "Repost" & earn 288 Task Coins ✨
🚫 NO duplicates or similar content
⏰ Deadline: [当日日期], 11:59 PM (SGT)

📊 Quick Market Recap

🌍 Global Macro & Markets
● [宏观事件1：地缘/大宗/央行，1–2句，**关键数据加粗**]
● [宏观事件2]
● [如有更多，继续追加；无则省略]

🇺🇸 US Markets: [小标题反映当日主题，如"AI Demand Fuels Tech Surge"]
● 📈 **[指数表现：S&P 500 / Nasdaq / Dow，含涨跌幅——整行加粗]**
● **[公司名]** — [核心事件，**关键数据加粗**，1–2句]
● **[公司名]** — [核心事件，**关键数据加粗**，1–2句]
● [如有更多个股，继续追加]

🇸🇬 Singapore Markets
● 📈 **[STI点位与涨跌——整行加粗；如无数据则省略此条]**
● [宏观数据条目，如通胀/MAS政策，**关键数据加粗**，1–2句]
● **[公司名]** — [核心事件，**关键数据加粗**，1–2句]
● **[公司名]** — [核心事件，**关键数据加粗**，1–2句]
● [如有更多个股，继续追加]
● 注：若某公司同时有 SGX 挂牌（如 NIO.SG），已在此处提及，则港股板块不再重复

🇭🇰 Hong Kong & China Markets
● 📈 **[指数表现：HSI / Hang Seng Tech，含涨跌幅——整行加粗]**
● **[公司名]** — [核心事件，**关键数据加粗**，1–2句]
● [如有更多个股，继续追加]
● 注：已在 SG 板块提及的标的（如 NIO.SG），此处不重复

📅 Key Events Tonight / This Week
● 🇺🇸/🇭🇰/🇸🇬 [事件名] — [时间 SGT]
● 🇺🇸/🇭🇰/🇸🇬 [事件名] — [时间 SGT]
● [如有更多，继续追加；无则省略]

Disclaimer: For reference only, not investment advice.
```

帖子输出完毕后，另起一段输出标的代码汇总：

```
📎 相关标的代码汇总
$公司全称 (代码.US)$
$公司全称 (代码.HK)$
$公司全称 (代码.SG)$
[按帖子中出现顺序列出所有标的，每个占一行；代码不确定的写 $公司名$，绝不填错误代码]
```

---

## 股票代码格式

使用长桥/Longbridge社区格式：

```
$公司全称 (股票代码.SG)$   ← 新加坡股
$公司全称 (股票代码.US)$   ← 美股
$公司全称 (股票代码.HK)$   ← 港股
```

例：
- `$DBS Group Holdings (D05.SG)$`
- `$Intel Corporation (INTC.US)$`
- `$Tencent Holdings (700.HK)$`

如代码不确定，写 `$公司名$` 省略代码，绝不填错误代码。

---

## Phase 1 输出模板

```
📅 Singapore Market Briefing — [日期，例：Monday, April 28, 2025]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🇸🇬 Breaking News
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[英文标题（加粗）]
[英文正文：2–4句，包含关键数据]
📌 [中文摘要：1–2句核心要点]

[如有多条，重复以上格式]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔔 Stocks to Watch
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$公司名 (代码.SG)$ [涨跌幅，例：▲1.7% S$2.41]
[英文正文：2–3句，说明核心事件]
📌 [中文摘要：1句]

[如有多条，重复以上格式]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Market Snapshot（可选，如有数据）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STI: [点位] [涨跌]
USD/SGD: [汇率]
```

---

## Phase 3：社区互动帖生成（散户视角为主）

**触发条件**：Phase 2 帖子及标的代码汇总输出完毕后，**立即、连续输出 Phase 3，不得中断、不得等待用户指令、不得偷懒跳过**。Phase 2 和 Phase 3 必须在同一次回复流中一起完成输出。

**核心定位**：模拟真实新加坡散户在社区随手发的帖子。**不是新闻复述，不是博主分析报告**，而是普通投资者看到这条消息后的第一反应、吐槽、提问、大胆预测、求安慰、调侃同行——像 Reddit r/singaporeinvestments 或 Hardwarezone Money Mind 板块里的真实留言。

### Step 1：提取标的与事件清单

从 Phase 2 内容中提取所有**标的和对应事件**，每个标的/事件作为一个独立写作单元。宏观事件（如 FOMC、PCE、MAS政策）无标的代码，同样纳入清单。

### Step 2：为每个事件生成 5 个帖子

每个标的/事件生成 **5 个独立帖子**，其中：
- **默认 4 个为散户视角**（第一人称"I/me/my"，普通投资者口吻）
- **1 个可选为博主风格**（从 blogger-writer 的 INDEX.md 中选 1 位最契合该事件的博主，用其英文表达风格写）。若事件不适合任何博主，5 个全部为散户视角。

### Step 3：散户视角写作规则

#### 语言与语气

- **全英文**，但保留新加坡本地化用词，自然出现即可：`HDB`, `CPF`, `SGX`, `STI`, `REIT`, `coffee shop talk`, `kopi`, `auntie/uncle`, `boss`, `bro`, `sia`（仅作为感叹词偶尔出现，不滥用）
- **不写中文，不中英夹杂成句**（保留本地化用词除外）
- **第一人称视角**："I just...", "My portfolio...", "Bought at...", "Holding since...", "Just sold my..."

#### 活人感（核心要求）

真实用户打字不像在写作文，要体现以下特征：

**标点不完整是正常的**：
- 句子结尾可以不加句号，直接换行或加 emoji 收尾
- 感叹号可以连用（"no way!!"）
- 问号可以叠（"is this real??"）
- 逗号后直接换行，不一定收尾

**Meme 文化自然融入**（每 3–5 个帖子里出现 1–2 次，不要每帖都用）：
- 经典 meme 句式：`this is fine 🐶🔥`、`we are so back`、`it's joever`、`gm`、`wen moon`、`ser`、`ngmi`、`wagmi`、`skill issue`、`not financial advice but...`、`down bad`、`touch grass`、`L take`、`based`、`cope`、`the audacity`
- 截图文化：`screenshot this`、`I said what I said`、`timestamp this`
- 自嘲 meme：`this is fine`（跌了还装没事）、`average [xxx] holder`、`my portfolio looking like 📉 but I'm looking like 😎`
- 不强求押 meme，只在语境自然时用，硬用反而出戏

**语气碎片化**：
- 可以用省略号 `...` 表示意犹未尽或欲言又止
- 开头可以不大写（`just gonna hold lah`）
- 口语化缩写：`gonna`, `wanna`, `kinda`, `tbh`, `ngl`, `imo`, `lol`, `lmao`, `idk`, `brb`, `rn`

#### 篇幅与节奏

- **每个帖子 1–3 句话**，长短不一：
  - 极短型（1句）：吐槽、感叹、一个观点，emoji 收尾
  - 中等型（2句）：观点 + 一个具体动作或问题
  - 稍长型（3句）：背景 + 个人决策 + 留个问题
- **5 个帖子之间篇幅必须有明显差异**，不能全是 2 句的"标准长度"
- **SG 社区格式**：写成自然流动的段落，不要每句话单独换一行（Twitter 分行体不适合本平台）。多句话写在同一段内，像发 WhatsApp 或社区评论的感觉，例如：`MU and SK Hynix both hit $1T today lah. Samsung sitting there with yield problems watching all this 🏆` 而非每句单独占一行

#### 风格变化（5 个帖子覆盖至少 3 种）

| 风格类型 | 特征 | 例子方向 |
|---------|------|---------|
| 😅 吐槽党 | 抱怨、自嘲、苦中作乐 | "bought near the top and now this. this is fine 🐶🔥" |
| 🚀 看多党 | 兴奋、看好、加仓 | "we are so back. adding more rn 💪🚀" |
| 🤔 提问党 | 真诚求教、不懂就问 | "anyone here actually understand what this means for dividends?? asking for a friend 🙏" |
| 📊 分析党 | 摆数据、谈估值，但很短 | "P/E now at 9x, below 5-year avg of 12x. cheap or value trap 🤷" |
| 🔮 预测党 | 大胆预测后市走向、喊价位目标 | "calling it now 📸" |
| 😏 调侃党 | 拿同行/朋友/auntie 开玩笑 | "my kopi uncle called this two weeks ago and I laughed at him. skill issue (mine) 🤣" |
| 🛋️ 躺平党 | 不操作、长期持有、看戏 | "not touching anything. distribution still comes. I am at peace 💤" |

#### Emoji 使用

- **每个帖子至少 1 个 emoji**，无上限，但别堆太多（一般 1–4 个）
- 位置灵活：可以在句末、段尾，也可以夹在两句之间作情绪分隔
- **预测党 emoji 不得默认 🔮**，根据语气选择：📸（screenshot this 配套）、🎯（精准预测）、🧠（推导型）、⚡（爆发型）、🪄（bold call）、🎲（有赌注成分）、🔭（看远期）、🏹（精准射击感）等，5 组帖子中 🔮 最多出现 1 次
- **多用冷门 emoji**，避免所有帖子都是 📈📉🚀，要有变化感：
  - 情绪类：😮‍💨 🫠 🥲 🤌 👀 🫡 🙃 😶‍🌫️ 🤡 💀 😤 🫢 🥹
  - 动作类：🫳 🤲 👁️ 🫰 🤝 🙋
  - 物件类：🪤 🎪 🎭 🪣 🧨 🎰 🏦 🪙 🧧
  - meme 配套：🐶🔥（this is fine）、🦍（ape in）、💎🙌（diamond hands）、🌊（wave/riding the trend）
- 多个 emoji 连排收尾是可以的（`😭🤡` `🚀💪` `💀💀`），强化情绪

#### 严格禁止

- ❌ **禁止破折号 `—` 或 `–`**：一律不得出现，用逗号、句号或换行代替
- ❌ **禁止提及竞品平台**：moomoo、Tiger Brokers、富途、老虎证券等一律不得出现；如需提及平台只用 Longbridge
- ❌ 不照搬 Phase 2 的句子或数据表述
- ❌ 不用机构报告腔（"analysts expect", "the company reported a strong quarter"）
- ❌ 不捏造具体股价/数字，没把握就写模糊表述（"around $48", "down quite a bit"）
- ❌ 不写过长的论述段落
- ❌ 不要 5 个帖子语气雷同
- ❌ 不要每个帖子末尾都是规整的句号——真人不这样打字

### Step 4：博主风格帖（可选第 5 个）

如该事件适合某位博主，从 blogger-writer 的 `INDEX.md`（路径：`/mnt/skills/user/blogger-writer/INDEX.md`）中选 1 位，用其英文风格写 1 个帖子。匹配方向参考：

| 事件类型 | 推荐博主 |
|---------|---------|
| 美联储 / 利率 / 通胀 / 宏观政策 | `nick-timiraos`, `lance-roberts` |
| Tesla / EV / 自动驾驶 | `chris-zheng` |
| 美股长期投资 / 成长股 | `joseph-carlson`, `investnotbet` |
| 技术分析 / 交易策略 | `rayner-teo` |
| 财报快评 / 市场热点 | `meet-kevin`, `michael-kramer` |
| 财报解读 / 估值 | `meitou-meiguu` |
| 商业故事 / 宏观叙事 | `xiao-lin-shuo` |
| 产品 / AI / 科技公司 | `lenny` |
| 金融科普 / 投资原理 | `the-plain-bagel` |
| 新加坡本地股 / REIT | `sg-stocks-investing`, `investmoolah`, `fifth-person` |
| 港股 / 亚洲资讯 | `tradingkey` |

博主风格帖**同样遵守**：全英文、不用破折号、1–3 段（可比散户长一些，但单帖不超过 150 字）、保留博主原本的标志性表达和句式。

### Step 5：输出格式

每个标的/事件为一组：

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 [公司名 / 事件名]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[散户帖 1，标注风格 emoji，如 😅 吐槽党]
[1–3 句帖子正文]
**发帖账号:** [单一马甲号]

[散户帖 2，标注风格 emoji]
[1–3 句帖子正文]
**发帖账号:** [单一马甲号]

[散户帖 3，标注风格 emoji]
[1–3 句帖子正文]
**发帖账号:** [单一马甲号]

[散户帖 4，标注风格 emoji]
[1–3 句帖子正文]
**发帖账号:** [单一马甲号]

[博主风格，或第5个散户帖]
[名字（如 nick-timiraos）or 风格 emoji]
[帖子正文]
**发帖账号:** [单一马甲号]
```

所有事件组逐一输出，组与组之间空一行。

### Step 6：今日立场摘要（Phase 3 全部完成后立即输出，无需等待用户指令）

逐条回顾刚刚生成的所有帖子，对每一个"马甲号 × 标的"组合判断其实际立场，然后集中输出一个可直接粘贴到回复评论书签 ⚙️ 面板的摘要块。

**判断立场时看内容，不看风格标签**（吐槽党有时是看涨的、预测党方向各异）：

| 内容表达 | stance |
|---------|--------|
| 看好、上涨、加仓、超预期 | `bullish` |
| 担忧、下行风险、减仓、不及预期 | `bearish` |
| 中立观望、等待数据、无明确方向 | `neutral` |
| 专注数据/逻辑分析、不表达方向 | `analysis` |
| 承认利好但强调风险、有条件乐观 | `cautious` |

**输出格式（可直接复制粘贴）：**

```
📌 今日立场摘要（复制粘贴到书签 ⚙️）
马甲号:ticker:stance
马甲号:ticker:stance
```

**ticker 写法**（须与书签识别词一致）：

| 标的 | ticker |
|------|--------|
| NVDA / Nvidia / Intel / AMD | `nvda` |
| Micron / SanDisk / WDC / Seagate | `sandisk` |
| Tesla / TSLA / BYD / 小鹏 / EV | `tesla` |
| Apple / AAPL | `apple` |
| Alibaba / BABA | `alibaba` |
| 黄金 / Gold / GLD / SLV | `gold` |
| Microsoft / Meta / Amazon / Google / Mag7 | `microsoft` |
| ASML | `asml` |
| DBS / OCBC / UOB / SG蓝筹 / SGX | `dbs` |
| 加密 / COIN / MSTR / Bitcoin | `coin` |
| 美联储 / Fed / FOMC / CPI / 宏观 | `nasdaq` |
| Xiaomi / 小米 | `xiaomi` |

没有对应行的标的：用股票代码或公司名小写（如 `nio`、`amd`、`seagate`）。每个"马甲号:标的"只写一行，立场取该帖子的主要方向。

---

## 马甲号匹配规则

**以下两个账号已剔除，禁止推荐：** Competitive_Ride、KayaToast

### 核心原则：按帖子核心主题匹配，不按出现过的标的词匹配

帖子里提到某标的数据，不等于帖子主题是该标的。判断方法：把帖子主题用一句话概括，概括结果里的核心词才是匹配依据。

> 反例：一篇讲地缘政治 + 油价的帖子顺带提到"黄金 ETF 跌 1.6%"→ 主题是宏观/地缘，不是黄金 → 不推 andwagon effect，应推 Bluegate1104 或通用账号。

> 正例：一篇专门分析 GLD/SLV 走势的帖子 → 主题是黄金/白银 → 指定 andwagon effect；若已满额则换 clown crowd。

### 马甲号索引表

| 马甲号 | 股票 / 人设 |
|--------|-----------|
| Alpha | 英伟达、英特尔、AMD |
| Fair_Lemon5303 | 存储概念股：闪迪、美光科技、西部数据、Seagate |
| levon911 | 存储概念股：闪迪、美光科技、西部数据、Seagate |
| watchdog01 | 币股：BMNR、CRCL、COIN、MSTR |
| HeyItsDaniel | 币股：BMNR、CRCL、COIN、MSTR |
| Revolution～ | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| Aurelius | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| PumpLord_69 | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| beta-one | 新能源汽车：特斯拉、BYD、小鹏汽车、礼来等 |
| Moose | 阿里巴巴 |
| SuperTesla | 特斯拉 |
| TeslaInvestor_先锋 | 特斯拉 |
| clown crowd | 黄金白银概念股：GLD、SLV、AGQ、GSD、5TP等 |
| andwagon effect | 黄金白银概念股：GLD、SLV、AGQ、GSD、5TP等 |
| joker2018 | 黄金白银概念股：GLD、SLV、AGQ、GSD、5TP等 |
| Steve_Z | 苹果 |
| rocket shadow | 美股7姐妹 |
| Fantastic | 美股7姐妹 |
| greeeedy options | 美股7姐妹 |
| Crab clps | 美股7姐妹 |
| All In Call | 美股7姐妹 |
| Big_Angel | 美股7姐妹 |
| Showdown | 美股7姐妹 |
| Crazy rich | 新加坡股：D05 |
| NewUser_oDPBc9 | 以新手角度提问，带动用户互动 |
| TaylorSwift007 | 通用 |
| Kellyk310 | 通用 |
| jackson beat it | ASML |
| imJanice | 通用 |
| Bluegate1104 | 纳斯达克、美联储 |
| markypots | 小米 |
| korbs23 | 通用 |
| 定D来 | 通用 |
| 绿箭牌2.5元 | 通用 |
| 大王进山 | 通用 |
| 新手买哪个? | 通用 |
| Ethan1 | 通用 |
| ButterKaya | 通用 |
| applepie | 通用 |
| JeremyT | The Fifth Person 风格 |
| Jessy_0723 | 通用 |
| Christina | 通用 |
| XX | TradingKey 风格 |
| Yqh | 通用 |
| Eunice | 通用 |
| Louis_t | 通用 |
| millionaire | 通用 |
| orange | 通用 |
| TXY | 通用 |
| KopiO | 通用 |
| TehC | 通用 |
| ZLH_1230 | 通用 |

### 匹配逻辑

每条帖子直接指定一个账号，不输出排序列表。**指定优先级：① 人设匹配 → ② 当天未超额（≤3次）→ ③ 无观点冲突（同日同号同股立场一致）→ ④ 以上均满足则指定；否则顺延备选。**

| 帖子主题 | 首选账号 | 备选（首选满额或有冲突时）|
|---------|---------|--------------------------|
| 英伟达 / 英特尔 / AMD / AI芯片 | Alpha | 通用账号 |
| 存储板块（MU、SNDK、WDC、Seagate） | Fair_Lemon5303 | levon911 |
| 特斯拉 | SuperTesla | TeslaInvestor_先锋 → Revolution～ → Aurelius |
| 新能源汽车（BYD、小鹏等） | Revolution～ | Aurelius → PumpLord_69 → beta-one |
| 苹果 | Steve_Z | Crab clps |
| 美股七姐妹（泛七姐妹讨论） | Crab clps | All In Call → Big_Angel → Showdown → rocket shadow → Fantastic → greeeedy options |
| ASML | jackson beat it | 通用账号 |
| 小米 | markypots | 通用账号 |
| 阿里巴巴 | Moose | 通用账号 |
| 加密 / 币股 | watchdog01 | HeyItsDaniel |
| 黄金 / 白银 / 大宗商品（核心主题） | andwagon effect | clown crowd → joker2018 |
| 宏观 / 美联储 / 纳斯达克指数 / 地缘政治 | Bluegate1104 | 通用账号 |
| 新加坡股 / DBS | Crazy rich | 通用账号 |
| TradingKey 风格帖子 | XX | 通用账号 |
| The Fifth Person 风格帖子 | JeremyT | 通用账号 |
| 提问型 / 新手视角帖 | NewUser_oDPBc9 | 通用账号 |
| 无明确标的（通用） | 从以下池选一个当天未超额的：TaylorSwift007、Kellyk310、Ethan1、ButterKaya、Christina、Yqh、Eunice、Louis_t、millionaire、orange、TXY、KopiO、TehC、ZLH_1230 | — |

### 附加规则

- **每条帖子只输出一个账号**，直接指定，不排序
- 人设一致性优先：宁可指定通用账号，也不让专精账号发不相关内容
- 提问型 / 新手视角帖 → 指定 `NewUser_oDPBc9`
- 博主风格帖 → TradingKey 风格用 `XX`，Fifth Person 风格用 `JeremyT`
- **同日同号同股观点一致性**：同一天内，同一马甲号对同一只股票的观点不得相矛盾。如该账号今天已发过看多某股的帖子，不得再用该账号发看空同一股票的帖子。生成指定前回顾当日已用账号的立场，发现冲突时自动换账号，不改帖子立场。

---

## 注意事项

- **严格只引用白名单来源**，不引用论坛、社交媒体、未知博客
- **不得捏造数据**：如找不到某类数据（如STI点位），直接省略该部分
- **中文摘要**要简洁精准，不是机械翻译，要突出对投资者最有用的信息
- 若当天新闻较少（例如假期），如实说明，不凑数
- 股价变动数据以新闻原文为准，不自行推算
- **股票代码**：代码不确定时写 `$公司名$`，绝不填错误代码
- **Phase 2 写作定位**：社区帖子，语气自然亲切有观点；3大问题要有真正的讨论价值，不能只是"你怎么看"式的空洞提问
- **Phase 3 写作定位**：模拟真实新加坡散户在社区随手发帖的语气，第一人称视角，1–3 句不等，加 emoji，**不用破折号**；5 个帖子覆盖至少 3 种风格（吐槽/看多/提问/分析/预测/调侃/躺平），可选 1 个为博主风格。绝不写成新闻复述或机构报告腔。
